import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import Sidebar from "@/components/dashboard/sidebar";
import StatsCards from "@/components/dashboard/stats-cards";
import RealTimeActivity from "@/components/dashboard/real-time-activity";
import ConfigurationPanel from "@/components/dashboard/configuration-panel";
import BotSettings from "@/components/dashboard/bot-settings";
import TransactionTable from "@/components/dashboard/transaction-table";
import NotificationSettings from "@/components/dashboard/notification-settings";
import AdvancedMonitoring from "@/components/dashboard/advanced-monitoring";
import { RefreshCw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useWebSocket } from "@/hooks/use-websocket";
import { useToast } from "@/hooks/use-toast";

export default function Dashboard() {
  const { toast } = useToast();
  const wsData = useWebSocket(`ws://${window.location.host}`);
  const [activeTab, setActiveTab] = useState("dashboard");

  const { data: stats, isLoading: statsLoading, refetch: refetchStats } = useQuery({
    queryKey: ['/api/dashboard/stats'],
  });

  const { data: botStatus, isLoading: statusLoading } = useQuery({
    queryKey: ['/api/dashboard/bot-status'],
    refetchInterval: 10000, // Refresh every 10 seconds
  });

  const { data: recentTransactions, isLoading: transactionsLoading, refetch: refetchTransactions } = useQuery({
    queryKey: ['/api/dashboard/transactions'],
  });

  const handleRefresh = async () => {
    try {
      await Promise.all([refetchStats(), refetchTransactions()]);
      toast({
        title: "Data refreshed",
        description: "Dashboard data has been updated successfully.",
      });
    } catch (error) {
      toast({
        title: "Refresh failed",
        description: "Failed to refresh dashboard data.",
        variant: "destructive",
      });
    }
  };

  const isLoading = statsLoading || statusLoading || transactionsLoading;

  const renderTabContent = () => {
    switch (activeTab) {
      case "dashboard":
        return (
          <>
            <StatsCards stats={stats} isLoading={statsLoading} />
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mt-8">
              <RealTimeActivity 
                transactions={recentTransactions} 
                isLoading={transactionsLoading}
                wsData={wsData}
              />
              <ConfigurationPanel />
            </div>
          </>
        );
      case "monitoring":
        return <RealTimeActivity transactions={recentTransactions} isLoading={transactionsLoading} wsData={wsData} />;
      case "history":
        return <TransactionTable />;
      case "bots":
        return <BotSettings />;
      case "config":
        return <ConfigurationPanel />;
      case "notifications":
        return <NotificationSettings />;
      case "advanced":
        return <AdvancedMonitoring />;
      default:
        return <div>Page not found</div>;
    }
  };

  const getPageTitle = () => {
    switch (activeTab) {
      case "dashboard": return { title: "Dashboard Overview", desc: "Real-time monitoring for GP token buy-backs" };
      case "monitoring": return { title: "Live Monitoring", desc: "Real-time transaction tracking and alerts" };
      case "history": return { title: "Transaction History", desc: "Historical data and analytics" };
      case "bots": return { title: "Bot Management", desc: "Configure Telegram and Notion bots" };
      case "config": return { title: "Configuration", desc: "Monitoring settings and preferences" };
      case "notifications": return { title: "Notification Settings", desc: "Customize alerts and notifications" };
      case "advanced": return { title: "Advanced Settings", desc: "API configuration and performance tuning" };
      default: return { title: "Dashboard", desc: "Token monitoring system" };
    }
  };

  const pageInfo = getPageTitle();

  return (
    <div className="flex h-screen bg-background">
      <Sidebar 
        activeTab={activeTab}
        onTabChange={setActiveTab}
        botStatus={botStatus} 
      />
      
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Header */}
        <header className="bg-surface shadow-sm border-b border-border px-6 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-2xl font-semibold text-foreground">{pageInfo.title}</h2>
              <p className="text-sm text-muted-foreground mt-1">{pageInfo.desc}</p>
            </div>
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2 px-3 py-2 bg-green-50 dark:bg-green-950 rounded-lg">
                <div className="w-2 h-2 bg-success rounded-full animate-pulse"></div>
                <span className="text-sm font-medium text-success">Live</span>
              </div>
              <Button onClick={handleRefresh} disabled={isLoading}>
                <RefreshCw className={`mr-2 h-4 w-4 ${isLoading ? 'animate-spin' : ''}`} />
                Refresh
              </Button>
            </div>
          </div>
        </header>

        {/* Main Content */}
        <main className="flex-1 overflow-auto p-6">
          {renderTabContent()}
        </main>
      </div>
    </div>
  );
}
