import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Wallet, Coins, Clock, Bell, Save, TestTube, Copy } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";

const configSchema = z.object({
  walletAddress: z.string().min(32, "Invalid wallet address"),
  tokenAddress: z.string().min(32, "Invalid token address"),
  tokenSymbol: z.string().min(1, "Token symbol is required"),
  pollingInterval: z.number().min(1).max(60),
  alertThreshold: z.number().min(1).max(1440),
});

type ConfigFormData = z.infer<typeof configSchema>;

export default function ConfigurationPanel() {
  const { toast } = useToast();

  const { data: configs } = useQuery({
    queryKey: ['/api/monitoring/configs'],
  });

  const activeConfig = configs?.[0]; // Use first config for now

  const form = useForm<ConfigFormData>({
    resolver: zodResolver(configSchema),
    defaultValues: {
      walletAddress: activeConfig?.walletAddress || "QPKJCvwZNMLnShg6nrEnVPt32u9j5Psdufy2cBoiSi1",
      tokenAddress: activeConfig?.tokenAddress || "",
      tokenSymbol: activeConfig?.tokenSymbol || "GP",
      pollingInterval: activeConfig?.pollingInterval || 1,
      alertThreshold: activeConfig?.alertThreshold || 60,
    },
  });

  const saveConfigMutation = useMutation({
    mutationFn: async (data: ConfigFormData) => {
      if (activeConfig) {
        return apiRequest('PUT', `/api/monitoring/configs/${activeConfig.id}`, data);
      } else {
        return apiRequest('POST', '/api/monitoring/configs', data);
      }
    },
    onSuccess: () => {
      toast({
        title: "Configuration saved",
        description: "Monitoring configuration has been updated successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/monitoring/configs'] });
    },
    onError: () => {
      toast({
        title: "Save failed",
        description: "Failed to save configuration. Please try again.",
        variant: "destructive",
      });
    },
  });

  const testConnectionMutation = useMutation({
    mutationFn: async () => {
      // Mock test - in real implementation, this would test Solana connection
      await new Promise(resolve => setTimeout(resolve, 1000));
      return { success: true };
    },
    onSuccess: () => {
      toast({
        title: "Connection successful",
        description: "Successfully connected to Solana network.",
      });
    },
    onError: () => {
      toast({
        title: "Connection failed",
        description: "Failed to connect to Solana network.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: ConfigFormData) => {
    saveConfigMutation.mutate(data);
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast({
      title: "Copied",
      description: "Address copied to clipboard.",
    });
  };

  return (
    <Card className="bg-surface border-border">
      <CardHeader className="border-b border-border">
        <CardTitle className="text-lg font-semibold text-foreground">Quick Configuration</CardTitle>
        <p className="text-sm text-muted-foreground">Manage monitoring settings</p>
      </CardHeader>
      <CardContent className="p-6">
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
          {/* Wallet Address */}
          <div>
            <Label className="flex items-center text-sm font-medium text-foreground mb-2">
              <Wallet className="mr-2 h-4 w-4" />
              Monitored Wallet Address
            </Label>
            <div className="relative">
              <Input
                {...form.register('walletAddress')}
                className="font-mono text-sm pr-10"
                placeholder="Enter wallet address..."
              />
              <Button
                type="button"
                variant="ghost"
                size="sm"
                className="absolute right-2 top-1/2 transform -translate-y-1/2 h-6 w-6 p-0"
                onClick={() => copyToClipboard(form.getValues('walletAddress'))}
              >
                <Copy className="h-3 w-3" />
              </Button>
            </div>
            {form.formState.errors.walletAddress && (
              <p className="text-sm text-destructive mt-1">
                {form.formState.errors.walletAddress.message}
              </p>
            )}
          </div>

          {/* Token Address */}
          <div>
            <Label className="flex items-center text-sm font-medium text-foreground mb-2">
              <Coins className="mr-2 h-4 w-4" />
              GP Token Address
            </Label>
            <Input
              {...form.register('tokenAddress')}
              className="font-mono text-sm"
              placeholder="Enter GP token address..."
            />
            {form.formState.errors.tokenAddress && (
              <p className="text-sm text-destructive mt-1">
                {form.formState.errors.tokenAddress.message}
              </p>
            )}
          </div>

          {/* Token Symbol */}
          <div>
            <Label className="flex items-center text-sm font-medium text-foreground mb-2">
              <Coins className="mr-2 h-4 w-4" />
              Token Symbol
            </Label>
            <Input
              {...form.register('tokenSymbol')}
              className="text-sm"
              placeholder="GP"
            />
          </div>

          {/* Polling Interval */}
          <div>
            <Label className="flex items-center text-sm font-medium text-foreground mb-2">
              <Clock className="mr-2 h-4 w-4" />
              Polling Interval (minutes)
            </Label>
            <Select 
              value={form.watch('pollingInterval').toString()}
              onValueChange={(value) => form.setValue('pollingInterval', parseInt(value))}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="1">1 minute</SelectItem>
                <SelectItem value="2">2 minutes</SelectItem>
                <SelectItem value="5">5 minutes</SelectItem>
                <SelectItem value="10">10 minutes</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Alert Threshold */}
          <div>
            <Label className="flex items-center text-sm font-medium text-foreground mb-2">
              <Bell className="mr-2 h-4 w-4" />
              Inactivity Alert (minutes)
            </Label>
            <Input
              type="number"
              {...form.register('alertThreshold', { valueAsNumber: true })}
              min="1"
              max="1440"
              className="text-sm"
            />
            {form.formState.errors.alertThreshold && (
              <p className="text-sm text-destructive mt-1">
                {form.formState.errors.alertThreshold.message}
              </p>
            )}
          </div>

          {/* Action Buttons */}
          <div className="flex space-x-3">
            <Button 
              type="submit" 
              className="flex-1"
              disabled={saveConfigMutation.isPending}
            >
              <Save className="mr-2 h-4 w-4" />
              {saveConfigMutation.isPending ? 'Saving...' : 'Save Settings'}
            </Button>
            <Button
              type="button"
              variant="outline"
              onClick={() => testConnectionMutation.mutate()}
              disabled={testConnectionMutation.isPending}
            >
              <TestTube className="mr-2 h-4 w-4" />
              {testConnectionMutation.isPending ? 'Testing...' : 'Test'}
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
}
