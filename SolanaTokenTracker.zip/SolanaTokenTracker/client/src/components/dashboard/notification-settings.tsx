import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { Input } from "@/components/ui/input";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useState } from "react";
import { Bell, Settings, MessageCircle, FileText, Timer, TrendingUp } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";

interface NotificationSettings {
  telegram: {
    enabled: boolean;
    buybackNotifications: boolean;
    tokenOutNotifications: boolean;
    inactivityAlerts: boolean;
    dailySummary: boolean;
    priceAlerts: boolean;
    minimumBuybackAmount: number;
    alertFrequency: number; // minutes
  };
  notion: {
    enabled: boolean;
    dailyReports: boolean;
    weeklyReports: boolean;
    monthlyReports: boolean;
    alertReports: boolean;
    scheduleTime: string[];
    includeCharts: boolean;
  };
  general: {
    soundNotifications: boolean;
    browserNotifications: boolean;
    emailNotifications: boolean;
    alertThreshold: number; // minutes of inactivity
  };
}

export default function NotificationSettings() {
  const { toast } = useToast();
  const [settings, setSettings] = useState<NotificationSettings>({
    telegram: {
      enabled: true,
      buybackNotifications: true,
      tokenOutNotifications: true,
      inactivityAlerts: true,
      dailySummary: false,
      priceAlerts: false,
      minimumBuybackAmount: 1000,
      alertFrequency: 60
    },
    notion: {
      enabled: true,
      dailyReports: true,
      weeklyReports: false,
      monthlyReports: false,
      alertReports: true,
      scheduleTime: ["06:00", "12:00", "17:00", "24:00"],
      includeCharts: false
    },
    general: {
      soundNotifications: true,
      browserNotifications: true,
      emailNotifications: false,
      alertThreshold: 60
    }
  });

  const { data: botConfigs } = useQuery({
    queryKey: ['/api/bots/configs'],
  });

  const saveSettingsMutation = useMutation({
    mutationFn: async (settings: NotificationSettings) => {
      // Save Telegram settings
      await apiRequest('POST', '/api/bots/configs', {
        type: 'telegram',
        isEnabled: settings.telegram.enabled,
        config: JSON.stringify({}), // Bot credentials stored separately
        notificationSettings: JSON.stringify(settings.telegram)
      });

      // Save Notion settings
      await apiRequest('POST', '/api/bots/configs', {
        type: 'notion',
        isEnabled: settings.notion.enabled,
        config: JSON.stringify({}),
        notificationSettings: JSON.stringify(settings.notion)
      });

      return true;
    },
    onSuccess: () => {
      toast({
        title: "Settings saved",
        description: "Notification preferences have been updated successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/bots/configs'] });
    },
    onError: () => {
      toast({
        title: "Save failed",
        description: "Failed to save notification settings.",
        variant: "destructive",
      });
    },
  });

  const handleSave = () => {
    saveSettingsMutation.mutate(settings);
  };

  const updateSetting = (category: keyof NotificationSettings, key: string, value: any) => {
    setSettings(prev => ({
      ...prev,
      [category]: {
        ...prev[category],
        [key]: value
      }
    }));
  };

  return (
    <div className="space-y-8">
      {/* Telegram Settings */}
      <Card className="bg-surface border-border">
        <CardHeader className="border-b border-border">
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 bg-blue-100 dark:bg-blue-950 rounded-lg flex items-center justify-center">
              <MessageCircle className="text-primary h-4 w-4" />
            </div>
            <CardTitle className="text-lg font-semibold text-foreground">
              Telegram Notifications
            </CardTitle>
          </div>
        </CardHeader>
        <CardContent className="p-6 space-y-6">
          {/* Main Toggle */}
          <div className="flex items-center justify-between p-4 bg-muted rounded-lg">
            <div>
              <Label className="text-sm font-medium text-foreground">Enable Telegram Notifications</Label>
              <p className="text-xs text-muted-foreground mt-1">Turn on/off all Telegram alerts</p>
            </div>
            <Switch
              checked={settings.telegram.enabled}
              onCheckedChange={(checked) => updateSetting('telegram', 'enabled', checked)}
            />
          </div>

          {settings.telegram.enabled && (
            <div className="space-y-4">
              {/* Notification Types */}
              <div className="grid grid-cols-2 gap-4">
                <div className="flex items-center justify-between">
                  <Label className="text-sm text-foreground">Buy-back Alerts</Label>
                  <Switch
                    checked={settings.telegram.buybackNotifications}
                    onCheckedChange={(checked) => updateSetting('telegram', 'buybackNotifications', checked)}
                  />
                </div>
                <div className="flex items-center justify-between">
                  <Label className="text-sm text-foreground">Token Outflow Alerts</Label>
                  <Switch
                    checked={settings.telegram.tokenOutNotifications}
                    onCheckedChange={(checked) => updateSetting('telegram', 'tokenOutNotifications', checked)}
                  />
                </div>
                <div className="flex items-center justify-between">
                  <Label className="text-sm text-foreground">Inactivity Alerts</Label>
                  <Switch
                    checked={settings.telegram.inactivityAlerts}
                    onCheckedChange={(checked) => updateSetting('telegram', 'inactivityAlerts', checked)}
                  />
                </div>
                <div className="flex items-center justify-between">
                  <Label className="text-sm text-foreground">Daily Summary</Label>
                  <Switch
                    checked={settings.telegram.dailySummary}
                    onCheckedChange={(checked) => updateSetting('telegram', 'dailySummary', checked)}
                  />
                </div>
              </div>

              {/* Minimum Amount */}
              <div>
                <Label className="text-sm font-medium text-foreground mb-2 block">
                  Minimum Buy-back Amount (GP)
                </Label>
                <Input
                  type="number"
                  value={settings.telegram.minimumBuybackAmount}
                  onChange={(e) => updateSetting('telegram', 'minimumBuybackAmount', parseInt(e.target.value))}
                  className="w-32"
                />
                <p className="text-xs text-muted-foreground mt-1">Only alert for buy-backs above this amount</p>
              </div>

              {/* Alert Frequency */}
              <div>
                <Label className="text-sm font-medium text-foreground mb-2 block">
                  Alert Frequency: {settings.telegram.alertFrequency} minutes
                </Label>
                <Slider
                  value={[settings.telegram.alertFrequency]}
                  onValueChange={(value) => updateSetting('telegram', 'alertFrequency', value[0])}
                  max={1440}
                  min={1}
                  step={1}
                  className="w-64"
                />
                <p className="text-xs text-muted-foreground mt-1">How often to check for inactivity</p>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Notion Settings */}
      <Card className="bg-surface border-border">
        <CardHeader className="border-b border-border">
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 bg-gray-100 dark:bg-gray-900 rounded-lg flex items-center justify-center">
              <FileText className="text-muted-foreground h-4 w-4" />
            </div>
            <CardTitle className="text-lg font-semibold text-foreground">
              Notion Reports
            </CardTitle>
          </div>
        </CardHeader>
        <CardContent className="p-6 space-y-6">
          {/* Main Toggle */}
          <div className="flex items-center justify-between p-4 bg-muted rounded-lg">
            <div>
              <Label className="text-sm font-medium text-foreground">Enable Notion Reports</Label>
              <p className="text-xs text-muted-foreground mt-1">Automatically generate reports in Notion</p>
            </div>
            <Switch
              checked={settings.notion.enabled}
              onCheckedChange={(checked) => updateSetting('notion', 'enabled', checked)}
            />
          </div>

          {settings.notion.enabled && (
            <div className="space-y-4">
              {/* Report Types */}
              <div className="grid grid-cols-2 gap-4">
                <div className="flex items-center justify-between">
                  <Label className="text-sm text-foreground">Daily Reports</Label>
                  <Switch
                    checked={settings.notion.dailyReports}
                    onCheckedChange={(checked) => updateSetting('notion', 'dailyReports', checked)}
                  />
                </div>
                <div className="flex items-center justify-between">
                  <Label className="text-sm text-foreground">Weekly Reports</Label>
                  <Switch
                    checked={settings.notion.weeklyReports}
                    onCheckedChange={(checked) => updateSetting('notion', 'weeklyReports', checked)}
                  />
                </div>
                <div className="flex items-center justify-between">
                  <Label className="text-sm text-foreground">Alert Reports</Label>
                  <Switch
                    checked={settings.notion.alertReports}
                    onCheckedChange={(checked) => updateSetting('notion', 'alertReports', checked)}
                  />
                </div>
                <div className="flex items-center justify-between">
                  <Label className="text-sm text-foreground">Include Charts</Label>
                  <Switch
                    checked={settings.notion.includeCharts}
                    onCheckedChange={(checked) => updateSetting('notion', 'includeCharts', checked)}
                  />
                </div>
              </div>

              {/* Schedule */}
              <div>
                <Label className="text-sm font-medium text-foreground mb-2 block">Report Schedule</Label>
                <div className="grid grid-cols-4 gap-2">
                  {["06:00", "12:00", "17:00", "24:00"].map((time) => (
                    <div key={time} className="flex items-center space-x-2">
                      <input
                        type="checkbox"
                        id={`schedule-${time}`}
                        checked={settings.notion.scheduleTime.includes(time)}
                        onChange={(e) => {
                          const newSchedule = e.target.checked
                            ? [...settings.notion.scheduleTime, time]
                            : settings.notion.scheduleTime.filter(t => t !== time);
                          updateSetting('notion', 'scheduleTime', newSchedule);
                        }}
                        className="rounded"
                      />
                      <Label htmlFor={`schedule-${time}`} className="text-sm text-foreground">
                        {time}
                      </Label>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* General Settings */}
      <Card className="bg-surface border-border">
        <CardHeader className="border-b border-border">
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 bg-purple-100 dark:bg-purple-950 rounded-lg flex items-center justify-center">
              <Settings className="text-purple-600 h-4 w-4" />
            </div>
            <CardTitle className="text-lg font-semibold text-foreground">
              General Settings
            </CardTitle>
          </div>
        </CardHeader>
        <CardContent className="p-6 space-y-6">
          <div className="grid grid-cols-2 gap-4">
            <div className="flex items-center justify-between">
              <Label className="text-sm text-foreground">Sound Notifications</Label>
              <Switch
                checked={settings.general.soundNotifications}
                onCheckedChange={(checked) => updateSetting('general', 'soundNotifications', checked)}
              />
            </div>
            <div className="flex items-center justify-between">
              <Label className="text-sm text-foreground">Browser Notifications</Label>
              <Switch
                checked={settings.general.browserNotifications}
                onCheckedChange={(checked) => updateSetting('general', 'browserNotifications', checked)}
              />
            </div>
          </div>

          {/* Alert Threshold */}
          <div>
            <Label className="text-sm font-medium text-foreground mb-2 block">
              Inactivity Alert Threshold: {settings.general.alertThreshold} minutes
            </Label>
            <Slider
              value={[settings.general.alertThreshold]}
              onValueChange={(value) => updateSetting('general', 'alertThreshold', value[0])}
              max={1440}
              min={5}
              step={5}
              className="w-64"
            />
            <p className="text-xs text-muted-foreground mt-1">Alert when no buy-backs for this duration</p>
          </div>
        </CardContent>
      </Card>

      {/* Save Button */}
      <div className="flex justify-end">
        <Button 
          onClick={handleSave} 
          disabled={saveSettingsMutation.isPending}
          className="px-8"
        >
          <Bell className="mr-2 h-4 w-4" />
          {saveSettingsMutation.isPending ? 'Saving...' : 'Save Settings'}
        </Button>
      </div>
    </div>
  );
}