import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Slider } from "@/components/ui/slider";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useState } from "react";
import { Settings2, Zap, Globe, Database, TrendingUp, BarChart3 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";

interface AdvancedSettings {
  apiSettings: {
    useSolscan: boolean;
    useHelius: boolean;
    useCustomRpc: boolean;
    customRpcUrl: string;
    fallbackMode: boolean;
    requestTimeout: number;
  };
  monitoring: {
    pollingInterval: number;
    transactionHistory: number;
    priceTracking: boolean;
    volumeAnalysis: boolean;
    patternDetection: boolean;
    smartFiltering: boolean;
  };
  performance: {
    cacheEnabled: boolean;
    batchProcessing: boolean;
    maxConcurrentRequests: number;
    rateLimitPerMinute: number;
  };
  analytics: {
    enableAnalytics: boolean;
    trackPatterns: boolean;
    generateInsights: boolean;
    exportData: boolean;
  };
}

export default function AdvancedMonitoring() {
  const { toast } = useToast();
  const [settings, setSettings] = useState<AdvancedSettings>({
    apiSettings: {
      useSolscan: true,
      useHelius: false,
      useCustomRpc: false,
      customRpcUrl: "",
      fallbackMode: true,
      requestTimeout: 10000
    },
    monitoring: {
      pollingInterval: 1,
      transactionHistory: 100,
      priceTracking: true,
      volumeAnalysis: true,
      patternDetection: false,
      smartFiltering: true
    },
    performance: {
      cacheEnabled: true,
      batchProcessing: true,
      maxConcurrentRequests: 5,
      rateLimitPerMinute: 60
    },
    analytics: {
      enableAnalytics: true,
      trackPatterns: true,
      generateInsights: false,
      exportData: true
    }
  });

  const { data: currentConfig } = useQuery({
    queryKey: ['/api/monitoring/config'],
  });

  const saveSettingsMutation = useMutation({
    mutationFn: async (settings: AdvancedSettings) => {
      const response = await apiRequest('POST', '/api/monitoring/config', {
        useAlternativeRpc: settings.apiSettings.useSolscan,
        rpcEndpoint: settings.apiSettings.customRpcUrl || "https://api.mainnet-beta.solana.com",
        pollingInterval: settings.monitoring.pollingInterval,
        advancedSettings: JSON.stringify(settings)
      });
      return response;
    },
    onSuccess: () => {
      toast({
        title: "Advanced settings saved",
        description: "Your monitoring configuration has been updated.",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/monitoring/config'] });
    },
    onError: () => {
      toast({
        title: "Save failed",
        description: "Failed to save advanced settings.",
        variant: "destructive",
      });
    },
  });

  const updateSetting = (category: keyof AdvancedSettings, key: string, value: any) => {
    setSettings(prev => ({
      ...prev,
      [category]: {
        ...prev[category],
        [key]: value
      }
    }));
  };

  const testApiConnection = async (apiType: string) => {
    try {
      const response = await apiRequest('POST', '/api/monitoring/test-connection', { apiType });
      toast({
        title: "Connection test",
        description: `${apiType} API connection successful!`,
      });
    } catch (error) {
      toast({
        title: "Connection failed",
        description: `Failed to connect to ${apiType} API.`,
        variant: "destructive",
      });
    }
  };

  return (
    <div className="space-y-8">
      {/* API Settings */}
      <Card className="bg-surface border-border">
        <CardHeader className="border-b border-border">
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 bg-green-100 dark:bg-green-950 rounded-lg flex items-center justify-center">
              <Globe className="text-green-600 h-4 w-4" />
            </div>
            <CardTitle className="text-lg font-semibold text-foreground">
              API Configuration
            </CardTitle>
          </div>
        </CardHeader>
        <CardContent className="p-6 space-y-6">
          {/* API Provider Selection */}
          <div className="grid grid-cols-2 gap-6">
            <div className="space-y-4">
              <div className="flex items-center justify-between p-4 bg-muted rounded-lg">
                <div>
                  <Label className="text-sm font-medium text-foreground">Solscan API</Label>
                  <p className="text-xs text-muted-foreground">High reliability, no rate limits</p>
                </div>
                <div className="flex items-center space-x-2">
                  <Switch
                    checked={settings.apiSettings.useSolscan}
                    onCheckedChange={(checked) => updateSetting('apiSettings', 'useSolscan', checked)}
                  />
                  <Button 
                    size="sm" 
                    variant="outline"
                    onClick={() => testApiConnection('solscan')}
                  >
                    Test
                  </Button>
                </div>
              </div>

              <div className="flex items-center justify-between p-4 bg-muted rounded-lg">
                <div>
                  <Label className="text-sm font-medium text-foreground">Helius API</Label>
                  <p className="text-xs text-muted-foreground">Advanced features, requires API key</p>
                </div>
                <div className="flex items-center space-x-2">
                  <Switch
                    checked={settings.apiSettings.useHelius}
                    onCheckedChange={(checked) => updateSetting('apiSettings', 'useHelius', checked)}
                  />
                  <Button 
                    size="sm" 
                    variant="outline"
                    onClick={() => testApiConnection('helius')}
                  >
                    Test
                  </Button>
                </div>
              </div>
            </div>

            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <Label className="text-sm font-medium text-foreground">Custom RPC Endpoint</Label>
                <Switch
                  checked={settings.apiSettings.useCustomRpc}
                  onCheckedChange={(checked) => updateSetting('apiSettings', 'useCustomRpc', checked)}
                />
              </div>
              
              {settings.apiSettings.useCustomRpc && (
                <Input
                  placeholder="https://your-custom-rpc.com"
                  value={settings.apiSettings.customRpcUrl}
                  onChange={(e) => updateSetting('apiSettings', 'customRpcUrl', e.target.value)}
                />
              )}

              <div className="flex items-center justify-between">
                <Label className="text-sm font-medium text-foreground">Fallback Mode</Label>
                <Switch
                  checked={settings.apiSettings.fallbackMode}
                  onCheckedChange={(checked) => updateSetting('apiSettings', 'fallbackMode', checked)}
                />
              </div>
              <p className="text-xs text-muted-foreground">Automatically switch to backup API when primary fails</p>
            </div>
          </div>

          {/* Request Timeout */}
          <div>
            <Label className="text-sm font-medium text-foreground mb-2 block">
              Request Timeout: {settings.apiSettings.requestTimeout}ms
            </Label>
            <Slider
              value={[settings.apiSettings.requestTimeout]}
              onValueChange={(value) => updateSetting('apiSettings', 'requestTimeout', value[0])}
              max={30000}
              min={1000}
              step={1000}
              className="w-64"
            />
            <p className="text-xs text-muted-foreground mt-1">Maximum time to wait for API responses</p>
          </div>
        </CardContent>
      </Card>

      {/* Monitoring Settings */}
      <Card className="bg-surface border-border">
        <CardHeader className="border-b border-border">
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 bg-blue-100 dark:bg-blue-950 rounded-lg flex items-center justify-center">
              <BarChart3 className="text-blue-600 h-4 w-4" />
            </div>
            <CardTitle className="text-lg font-semibold text-foreground">
              Advanced Monitoring
            </CardTitle>
          </div>
        </CardHeader>
        <CardContent className="p-6 space-y-6">
          {/* Polling Interval */}
          <div>
            <Label className="text-sm font-medium text-foreground mb-2 block">
              Polling Interval: {settings.monitoring.pollingInterval} minute(s)
            </Label>
            <Slider
              value={[settings.monitoring.pollingInterval]}
              onValueChange={(value) => updateSetting('monitoring', 'pollingInterval', value[0])}
              max={10}
              min={0.5}
              step={0.5}
              className="w-64"
            />
            <p className="text-xs text-muted-foreground mt-1">How often to check for new transactions</p>
          </div>

          {/* Transaction History */}
          <div>
            <Label className="text-sm font-medium text-foreground mb-2 block">
              Transaction History: {settings.monitoring.transactionHistory} transactions
            </Label>
            <Slider
              value={[settings.monitoring.transactionHistory]}
              onValueChange={(value) => updateSetting('monitoring', 'transactionHistory', value[0])}
              max={1000}
              min={10}
              step={10}
              className="w-64"
            />
            <p className="text-xs text-muted-foreground mt-1">Number of recent transactions to keep in memory</p>
          </div>

          {/* Advanced Features */}
          <div className="grid grid-cols-2 gap-4">
            <div className="flex items-center justify-between">
              <Label className="text-sm text-foreground">Price Tracking</Label>
              <Switch
                checked={settings.monitoring.priceTracking}
                onCheckedChange={(checked) => updateSetting('monitoring', 'priceTracking', checked)}
              />
            </div>
            <div className="flex items-center justify-between">
              <Label className="text-sm text-foreground">Volume Analysis</Label>
              <Switch
                checked={settings.monitoring.volumeAnalysis}
                onCheckedChange={(checked) => updateSetting('monitoring', 'volumeAnalysis', checked)}
              />
            </div>
            <div className="flex items-center justify-between">
              <Label className="text-sm text-foreground">Pattern Detection</Label>
              <Switch
                checked={settings.monitoring.patternDetection}
                onCheckedChange={(checked) => updateSetting('monitoring', 'patternDetection', checked)}
              />
            </div>
            <div className="flex items-center justify-between">
              <Label className="text-sm text-foreground">Smart Filtering</Label>
              <Switch
                checked={settings.monitoring.smartFiltering}
                onCheckedChange={(checked) => updateSetting('monitoring', 'smartFiltering', checked)}
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Performance Settings */}
      <Card className="bg-surface border-border">
        <CardHeader className="border-b border-border">
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 bg-orange-100 dark:bg-orange-950 rounded-lg flex items-center justify-center">
              <Zap className="text-orange-600 h-4 w-4" />
            </div>
            <CardTitle className="text-lg font-semibold text-foreground">
              Performance Optimization
            </CardTitle>
          </div>
        </CardHeader>
        <CardContent className="p-6 space-y-6">
          <div className="grid grid-cols-2 gap-6">
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <Label className="text-sm text-foreground">Enable Caching</Label>
                <Switch
                  checked={settings.performance.cacheEnabled}
                  onCheckedChange={(checked) => updateSetting('performance', 'cacheEnabled', checked)}
                />
              </div>
              <div className="flex items-center justify-between">
                <Label className="text-sm text-foreground">Batch Processing</Label>
                <Switch
                  checked={settings.performance.batchProcessing}
                  onCheckedChange={(checked) => updateSetting('performance', 'batchProcessing', checked)}
                />
              </div>
            </div>

            <div className="space-y-4">
              <div>
                <Label className="text-sm font-medium text-foreground mb-2 block">
                  Max Concurrent Requests: {settings.performance.maxConcurrentRequests}
                </Label>
                <Slider
                  value={[settings.performance.maxConcurrentRequests]}
                  onValueChange={(value) => updateSetting('performance', 'maxConcurrentRequests', value[0])}
                  max={20}
                  min={1}
                  step={1}
                  className="w-48"
                />
              </div>

              <div>
                <Label className="text-sm font-medium text-foreground mb-2 block">
                  Rate Limit: {settings.performance.rateLimitPerMinute}/min
                </Label>
                <Slider
                  value={[settings.performance.rateLimitPerMinute]}
                  onValueChange={(value) => updateSetting('performance', 'rateLimitPerMinute', value[0])}
                  max={300}
                  min={10}
                  step={10}
                  className="w-48"
                />
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Analytics Settings */}
      <Card className="bg-surface border-border">
        <CardHeader className="border-b border-border">
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 bg-purple-100 dark:bg-purple-950 rounded-lg flex items-center justify-center">
              <TrendingUp className="text-purple-600 h-4 w-4" />
            </div>
            <CardTitle className="text-lg font-semibold text-foreground">
              Analytics & Insights
            </CardTitle>
          </div>
        </CardHeader>
        <CardContent className="p-6 space-y-6">
          <div className="grid grid-cols-2 gap-4">
            <div className="flex items-center justify-between">
              <Label className="text-sm text-foreground">Enable Analytics</Label>
              <Switch
                checked={settings.analytics.enableAnalytics}
                onCheckedChange={(checked) => updateSetting('analytics', 'enableAnalytics', checked)}
              />
            </div>
            <div className="flex items-center justify-between">
              <Label className="text-sm text-foreground">Track Patterns</Label>
              <Switch
                checked={settings.analytics.trackPatterns}
                onCheckedChange={(checked) => updateSetting('analytics', 'trackPatterns', checked)}
              />
            </div>
            <div className="flex items-center justify-between">
              <Label className="text-sm text-foreground">Generate Insights</Label>
              <Switch
                checked={settings.analytics.generateInsights}
                onCheckedChange={(checked) => updateSetting('analytics', 'generateInsights', checked)}
              />
            </div>
            <div className="flex items-center justify-between">
              <Label className="text-sm text-foreground">Data Export</Label>
              <Switch
                checked={settings.analytics.exportData}
                onCheckedChange={(checked) => updateSetting('analytics', 'exportData', checked)}
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Save Button */}
      <div className="flex justify-end space-x-4">
        <Button variant="outline" onClick={() => window.location.reload()}>
          Reset to Defaults
        </Button>
        <Button 
          onClick={() => saveSettingsMutation.mutate(settings)} 
          disabled={saveSettingsMutation.isPending}
          className="px-8"
        >
          <Settings2 className="mr-2 h-4 w-4" />
          {saveSettingsMutation.isPending ? 'Saving...' : 'Save Advanced Settings'}
        </Button>
      </div>
    </div>
  );
}