import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { MessageCircle, FileText, Eye, EyeOff, Send, Database } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useState } from "react";

const telegramSchema = z.object({
  botToken: z.string().min(1, "Bot token is required"),
  chatId: z.string().min(1, "Chat ID is required"),
  enabled: z.boolean(),
});

const notionSchema = z.object({
  integrationSecret: z.string().min(1, "Integration secret is required"),
  pageUrl: z.string().url("Invalid page URL"),
  enabled: z.boolean(),
  schedule: z.array(z.string()).optional(),
});

type TelegramFormData = z.infer<typeof telegramSchema>;
type NotionFormData = z.infer<typeof notionSchema>;

export default function BotSettings() {
  const { toast } = useToast();
  const [showTelegramToken, setShowTelegramToken] = useState(false);
  const [showNotionSecret, setShowNotionSecret] = useState(false);

  const { data: botConfigs } = useQuery({
    queryKey: ['/api/bots/configs'],
  });

  const telegramConfig = botConfigs?.find((config: any) => config.type === 'telegram');
  const notionConfig = botConfigs?.find((config: any) => config.type === 'notion');

  const telegramForm = useForm<TelegramFormData>({
    resolver: zodResolver(telegramSchema),
    defaultValues: {
      botToken: telegramConfig ? JSON.parse(telegramConfig.config).botToken : "",
      chatId: telegramConfig ? JSON.parse(telegramConfig.config).chatId : "",
      enabled: telegramConfig?.isEnabled || false,
    },
  });

  const notionForm = useForm<NotionFormData>({
    resolver: zodResolver(notionSchema),
    defaultValues: {
      integrationSecret: notionConfig ? JSON.parse(notionConfig.config).integrationSecret : "",
      pageUrl: notionConfig ? JSON.parse(notionConfig.config).pageUrl : "",
      enabled: notionConfig?.isEnabled || false,
      schedule: notionConfig ? JSON.parse(notionConfig.config).schedule : ["06:00", "12:00", "17:00", "24:00"],
    },
  });

  const saveTelegramMutation = useMutation({
    mutationFn: async (data: TelegramFormData) => {
      return apiRequest('POST', '/api/bots/configs', {
        type: 'telegram',
        isEnabled: data.enabled,
        config: JSON.stringify({
          botToken: data.botToken,
          chatId: data.chatId,
        }),
      });
    },
    onSuccess: () => {
      toast({
        title: "Telegram bot saved",
        description: "Configuration has been updated successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/bots/configs'] });
    },
    onError: () => {
      toast({
        title: "Save failed",
        description: "Failed to save Telegram bot configuration.",
        variant: "destructive",
      });
    },
  });

  const saveNotionMutation = useMutation({
    mutationFn: async (data: NotionFormData) => {
      return apiRequest('POST', '/api/bots/configs', {
        type: 'notion',
        isEnabled: data.enabled,
        config: JSON.stringify({
          integrationSecret: data.integrationSecret,
          pageUrl: data.pageUrl,
          schedule: data.schedule,
        }),
      });
    },
    onSuccess: () => {
      toast({
        title: "Notion bot saved",
        description: "Configuration has been updated successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/bots/configs'] });
    },
    onError: () => {
      toast({
        title: "Save failed",
        description: "Failed to save Notion bot configuration.",
        variant: "destructive",
      });
    },
  });

  const testTelegramMutation = useMutation({
    mutationFn: async (data: TelegramFormData) => {
      return apiRequest('POST', '/api/bots/test/telegram', {
        config: { botToken: data.botToken, chatId: data.chatId }
      });
    },
    onSuccess: () => {
      toast({
        title: "Connection successful",
        description: "Telegram bot is working correctly.",
      });
    },
    onError: () => {
      toast({
        title: "Connection failed",
        description: "Failed to connect to Telegram bot.",
        variant: "destructive",
      });
    },
  });

  const testNotionMutation = useMutation({
    mutationFn: async (data: NotionFormData) => {
      return apiRequest('POST', '/api/bots/test/notion', {
        config: { integrationSecret: data.integrationSecret, pageUrl: data.pageUrl }
      });
    },
    onSuccess: () => {
      toast({
        title: "Connection successful",
        description: "Notion integration is working correctly.",
      });
    },
    onError: () => {
      toast({
        title: "Connection failed",
        description: "Failed to connect to Notion.",
        variant: "destructive",
      });
    },
  });

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mt-8">
      {/* Telegram Bot Settings */}
      <Card className="bg-surface border-border">
        <CardHeader className="border-b border-border">
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 bg-blue-100 dark:bg-blue-950 rounded-lg flex items-center justify-center">
              <MessageCircle className="text-primary h-4 w-4" />
            </div>
            <CardTitle className="text-lg font-semibold text-foreground">
              Telegram Bot Configuration
            </CardTitle>
          </div>
        </CardHeader>
        <CardContent className="p-6">
          <form onSubmit={telegramForm.handleSubmit((data) => saveTelegramMutation.mutate(data))} className="space-y-4">
            <div>
              <Label className="text-sm font-medium text-foreground">Bot Token</Label>
              <div className="relative mt-2">
                <Input
                  type={showTelegramToken ? "text" : "password"}
                  {...telegramForm.register('botToken')}
                  className="font-mono text-sm pr-10"
                  placeholder="8178383755:AAH5OwUM7GJq-OSx1dpieYB7lli-xuPjKhw"
                />
                <Button
                  type="button"
                  variant="ghost"
                  size="sm"
                  className="absolute right-2 top-1/2 transform -translate-y-1/2 h-6 w-6 p-0"
                  onClick={() => setShowTelegramToken(!showTelegramToken)}
                >
                  {showTelegramToken ? <EyeOff className="h-3 w-3" /> : <Eye className="h-3 w-3" />}
                </Button>
              </div>
              <p className="text-xs text-muted-foreground mt-1">Your Telegram bot token from BotFather</p>
              {telegramForm.formState.errors.botToken && (
                <p className="text-sm text-destructive mt-1">
                  {telegramForm.formState.errors.botToken.message}
                </p>
              )}
            </div>

            <div>
              <Label className="text-sm font-medium text-foreground">Chat ID</Label>
              <Input
                {...telegramForm.register('chatId')}
                className="mt-2"
                placeholder="Enter chat ID or @username"
              />
              <p className="text-xs text-muted-foreground mt-1">Where notifications will be sent</p>
              {telegramForm.formState.errors.chatId && (
                <p className="text-sm text-destructive mt-1">
                  {telegramForm.formState.errors.chatId.message}
                </p>
              )}
            </div>

            <div className="flex items-center justify-between p-3 bg-muted rounded-lg">
              <div>
                <p className="text-sm font-medium text-foreground">Enable Notifications</p>
                <p className="text-xs text-muted-foreground">Send buy-back and alert messages</p>
              </div>
              <Switch
                checked={telegramForm.watch('enabled')}
                onCheckedChange={(checked) => telegramForm.setValue('enabled', checked)}
              />
            </div>

            <div className="flex space-x-2">
              <Button type="submit" className="flex-1" disabled={saveTelegramMutation.isPending}>
                <Send className="mr-2 h-4 w-4" />
                {saveTelegramMutation.isPending ? 'Saving...' : 'Save Settings'}
              </Button>
              <Button
                type="button"
                variant="outline"
                onClick={() => testTelegramMutation.mutate(telegramForm.getValues())}
                disabled={testTelegramMutation.isPending}
              >
                {testTelegramMutation.isPending ? 'Testing...' : 'Test'}
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>

      {/* Notion Bot Settings */}
      <Card className="bg-surface border-border">
        <CardHeader className="border-b border-border">
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 bg-gray-100 dark:bg-gray-900 rounded-lg flex items-center justify-center">
              <FileText className="text-muted-foreground h-4 w-4" />
            </div>
            <CardTitle className="text-lg font-semibold text-foreground">
              Notion Bot Configuration
            </CardTitle>
          </div>
        </CardHeader>
        <CardContent className="p-6">
          <form onSubmit={notionForm.handleSubmit((data) => saveNotionMutation.mutate(data))} className="space-y-4">
            <div>
              <Label className="text-sm font-medium text-foreground">Integration Secret</Label>
              <div className="relative mt-2">
                <Input
                  type={showNotionSecret ? "text" : "password"}
                  {...notionForm.register('integrationSecret')}
                  className="font-mono text-sm pr-10"
                  placeholder="secret_..."
                />
                <Button
                  type="button"
                  variant="ghost"
                  size="sm"
                  className="absolute right-2 top-1/2 transform -translate-y-1/2 h-6 w-6 p-0"
                  onClick={() => setShowNotionSecret(!showNotionSecret)}
                >
                  {showNotionSecret ? <EyeOff className="h-3 w-3" /> : <Eye className="h-3 w-3" />}
                </Button>
              </div>
              <p className="text-xs text-muted-foreground mt-1">Your Notion integration secret</p>
              {notionForm.formState.errors.integrationSecret && (
                <p className="text-sm text-destructive mt-1">
                  {notionForm.formState.errors.integrationSecret.message}
                </p>
              )}
            </div>

            <div>
              <Label className="text-sm font-medium text-foreground">Page URL</Label>
              <Input
                type="url"
                {...notionForm.register('pageUrl')}
                className="mt-2 text-sm"
                placeholder="https://www.notion.so/..."
              />
              <p className="text-xs text-muted-foreground mt-1">Notion page where reports will be created</p>
              {notionForm.formState.errors.pageUrl && (
                <p className="text-sm text-destructive mt-1">
                  {notionForm.formState.errors.pageUrl.message}
                </p>
              )}
            </div>

            <div>
              <Label className="text-sm font-medium text-foreground mb-2 block">Report Schedule</Label>
              <div className="grid grid-cols-4 gap-2">
                {["06:00", "12:00", "17:00", "24:00"].map((time) => (
                  <div key={time} className="text-center">
                    <input
                      type="checkbox"
                      id={`schedule-${time}`}
                      className="mb-1"
                      defaultChecked={true}
                    />
                    <label htmlFor={`schedule-${time}`} className="block text-xs text-muted-foreground">
                      {time}
                    </label>
                  </div>
                ))}
              </div>
            </div>

            <div className="flex items-center justify-between p-3 bg-muted rounded-lg">
              <div>
                <p className="text-sm font-medium text-foreground">Auto Reports</p>
                <p className="text-xs text-muted-foreground">Generate scheduled reports</p>
              </div>
              <Switch
                checked={notionForm.watch('enabled')}
                onCheckedChange={(checked) => notionForm.setValue('enabled', checked)}
              />
            </div>

            <div className="flex space-x-2">
              <Button type="submit" className="flex-1" disabled={saveNotionMutation.isPending}>
                <Database className="mr-2 h-4 w-4" />
                {saveNotionMutation.isPending ? 'Saving...' : 'Save Settings'}
              </Button>
              <Button
                type="button"
                variant="outline"
                onClick={() => testNotionMutation.mutate(notionForm.getValues())}
                disabled={testNotionMutation.isPending}
              >
                {testNotionMutation.isPending ? 'Testing...' : 'Test'}
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
