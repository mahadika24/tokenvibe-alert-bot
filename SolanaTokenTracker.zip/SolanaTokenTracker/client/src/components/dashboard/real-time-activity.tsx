import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { ArrowDown, ArrowUp, Activity } from "lucide-react";
import { useEffect, useState } from "react";

interface Transaction {
  id: number;
  type: string;
  amount: string;
  solAmount?: string;
  timestamp: string;
  hash: string;
}

interface RealTimeActivityProps {
  transactions?: Transaction[];
  isLoading: boolean;
  wsData?: any;
}

export default function RealTimeActivity({ transactions, isLoading, wsData }: RealTimeActivityProps) {
  const [recentTransactions, setRecentTransactions] = useState<Transaction[]>([]);

  useEffect(() => {
    if (transactions) {
      setRecentTransactions(transactions);
    }
  }, [transactions]);

  useEffect(() => {
    if (wsData?.type === 'new_transaction') {
      setRecentTransactions(prev => [wsData.data, ...prev.slice(0, 9)]);
    }
  }, [wsData]);

  if (isLoading) {
    return (
      <Card className="bg-surface border-border">
        <CardHeader className="border-b border-border">
          <div className="flex items-center justify-between">
            <CardTitle className="text-lg font-semibold text-foreground">Real-time Activity</CardTitle>
            <Skeleton className="h-5 w-12" />
          </div>
        </CardHeader>
        <CardContent className="p-6">
          <div className="space-y-4 max-h-80 overflow-y-auto">
            {Array.from({ length: 3 }).map((_, i) => (
              <div key={i} className="flex items-center space-x-4 p-3 rounded-lg">
                <Skeleton className="w-10 h-10 rounded-full" />
                <div className="flex-1 space-y-1">
                  <Skeleton className="h-4 w-24" />
                  <Skeleton className="h-3 w-16" />
                </div>
                <div className="text-right space-y-1">
                  <Skeleton className="h-4 w-16" />
                  <Skeleton className="h-3 w-12" />
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="bg-surface border-border">
      <CardHeader className="border-b border-border">
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg font-semibold text-foreground">Real-time Activity</CardTitle>
          <div className="flex items-center space-x-2">
            <div className="w-2 h-2 bg-success rounded-full animate-pulse"></div>
            <span className="text-sm text-success font-medium">Live</span>
          </div>
        </div>
      </CardHeader>
      <CardContent className="p-6">
        <div className="space-y-4 max-h-80 overflow-y-auto">
          {recentTransactions && recentTransactions.length > 0 ? (
            recentTransactions.map((tx) => (
              <TransactionItem key={tx.id} transaction={tx} />
            ))
          ) : (
            <div className="flex flex-col items-center justify-center py-8 text-center">
              <Activity className="h-12 w-12 text-muted-foreground mb-4" />
              <p className="text-sm text-muted-foreground">No recent transactions</p>
              <p className="text-xs text-muted-foreground mt-1">Waiting for buy-back activity...</p>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}

interface TransactionItemProps {
  transaction: Transaction;
}

function TransactionItem({ transaction }: TransactionItemProps) {
  const isBuyBack = transaction.type === 'Buy-back';
  const bgColor = isBuyBack ? "bg-green-50 dark:bg-green-950" : "bg-orange-50 dark:bg-orange-950";
  const iconColor = isBuyBack ? "text-success" : "text-warning";
  const amountColor = isBuyBack ? "text-success" : "text-warning";

  return (
    <div className={`flex items-center space-x-4 p-3 ${bgColor} rounded-lg`}>
      <div className={`w-10 h-10 ${isBuyBack ? 'bg-success' : 'bg-warning'} rounded-full flex items-center justify-center`}>
        {isBuyBack ? (
          <ArrowDown className="text-white text-sm" />
        ) : (
          <ArrowUp className="text-white text-sm" />
        )}
      </div>
      <div className="flex-1">
        <p className="text-sm font-medium text-foreground">{transaction.type}</p>
        <p className="text-xs text-muted-foreground">{transaction.timestamp}</p>
      </div>
      <div className="text-right">
        <p className={`text-sm font-semibold ${amountColor}`}>{transaction.amount}</p>
        {transaction.solAmount && (
          <p className="text-xs text-muted-foreground">{transaction.solAmount}</p>
        )}
      </div>
    </div>
  );
}
