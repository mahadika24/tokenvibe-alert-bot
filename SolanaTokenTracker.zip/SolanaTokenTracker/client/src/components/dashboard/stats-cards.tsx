import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { 
  TrendingUp, 
  Coins, 
  Clock, 
  ArrowRightLeft 
} from "lucide-react";

interface StatsCardsProps {
  stats?: {
    dailyBuybacks: string;
    dailySol: string;
    avgFrequency: string;
    weeklyOutflow: string;
  };
  isLoading: boolean;
}

export default function StatsCards({ stats, isLoading }: StatsCardsProps) {
  const statsData = [
    {
      title: "Total Buy-backs Today",
      value: stats?.dailyBuybacks || "0 GP",
      change: "+12.5% from yesterday",
      changeType: "positive" as const,
      icon: TrendingUp,
      bgColor: "bg-green-100 dark:bg-green-950",
      iconColor: "text-success",
    },
    {
      title: "SOL Volume Today", 
      value: stats?.dailySol || "0 SOL",
      change: "+8.2% from yesterday",
      changeType: "positive" as const,
      icon: Coins,
      bgColor: "bg-blue-100 dark:bg-blue-950",
      iconColor: "text-primary",
    },
    {
      title: "Avg. Frequency",
      value: stats?.avgFrequency || "0 min",
      change: "per transaction",
      changeType: "neutral" as const,
      icon: Clock,
      bgColor: "bg-purple-100 dark:bg-purple-950",
      iconColor: "text-purple-600",
    },
    {
      title: "Tokens Out (Week)",
      value: stats?.weeklyOutflow || "0 GP",
      change: "Monitor closely",
      changeType: "warning" as const,
      icon: ArrowRightLeft,
      bgColor: "bg-amber-100 dark:bg-amber-950",
      iconColor: "text-warning",
    },
  ];

  if (isLoading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {Array.from({ length: 4 }).map((_, i) => (
          <Card key={i} className="bg-surface border-border">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div className="space-y-2">
                  <Skeleton className="h-4 w-24" />
                  <Skeleton className="h-6 w-16" />
                  <Skeleton className="h-3 w-20" />
                </div>
                <Skeleton className="h-12 w-12 rounded-lg" />
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
      {statsData.map((stat, index) => (
        <Card key={index} className="bg-surface border-border">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">{stat.title}</p>
                <p className="text-2xl font-bold text-foreground mt-1">{stat.value}</p>
                <p className={`text-sm mt-1 ${
                  stat.changeType === 'positive' ? 'text-success' :
                  stat.changeType === 'warning' ? 'text-warning' :
                  'text-muted-foreground'
                }`}>
                  {stat.changeType === 'positive' && (
                    <TrendingUp className="inline mr-1 h-3 w-3" />
                  )}
                  {stat.changeType === 'warning' && (
                    <ArrowRightLeft className="inline mr-1 h-3 w-3" />
                  )}
                  {stat.change}
                </p>
              </div>
              <div className={`w-12 h-12 ${stat.bgColor} rounded-lg flex items-center justify-center`}>
                <stat.icon className={`${stat.iconColor} text-xl`} />
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
