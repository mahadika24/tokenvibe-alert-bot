import { cn } from "@/lib/utils";
import { 
  ChartLine, 
  Gauge, 
  Eye, 
  History, 
  Bot, 
  Settings, 
  Bell,
  Zap
} from "lucide-react";

interface SidebarProps {
  activeTab: string;
  onTabChange: (tab: string) => void;
  botStatus?: {
    telegram: boolean;
    notion: boolean;
    monitoring: boolean;
  };
}

export default function Sidebar({ activeTab, onTabChange, botStatus }: SidebarProps) {
  const navItems = [
    { id: "dashboard", icon: Gauge, label: "Dashboard" },
    { id: "monitoring", icon: Eye, label: "Live Monitoring" },
    { id: "history", icon: History, label: "Transaction History" },
    { id: "bots", icon: Bot, label: "Bot Management" },
    { id: "config", icon: Settings, label: "Configuration" },
    { id: "notifications", icon: Bell, label: "Notifications" },
    { id: "advanced", icon: Zap, label: "Advanced Settings" },
  ];

  return (
    <div className="w-64 bg-surface shadow-lg border-r border-border flex flex-col">
      {/* Logo & Title */}
      <div className="p-6 border-b border-border">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
            <ChartLine className="text-primary-foreground text-lg" />
          </div>
          <div>
            <h1 className="text-lg font-semibold text-foreground">Token Monitor</h1>
            <p className="text-sm text-muted-foreground">Solana Tracker</p>
          </div>
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 p-4 space-y-2">
        {navItems.map((item) => (
          <button
            key={item.id}
            onClick={() => onTabChange(item.id)}
            className={cn(
              "w-full flex items-center space-x-3 px-3 py-2 rounded-lg font-medium transition-colors",
              activeTab === item.id
                ? "bg-blue-50 dark:bg-blue-950 text-primary"
                : "text-muted-foreground hover:bg-muted"
            )}
          >
            <item.icon className="w-5 h-5" />
            <span>{item.label}</span>
          </button>
        ))}
      </nav>

      {/* Bot Status */}
      <div className="p-4 border-t border-border">
        <h3 className="text-sm font-medium text-foreground mb-3">Bot Status</h3>
        <div className="space-y-2">
          <BotStatusItem 
            label="Telegram Bot" 
            status={botStatus?.telegram || false} 
          />
          <BotStatusItem 
            label="Notion Bot" 
            status={botStatus?.notion || false} 
          />
          <BotStatusItem 
            label="Monitoring" 
            status={botStatus?.monitoring || false}
            pulse={true}
          />
        </div>
      </div>
    </div>
  );
}

interface BotStatusItemProps {
  label: string;
  status: boolean;
  pulse?: boolean;
}

function BotStatusItem({ label, status, pulse }: BotStatusItemProps) {
  return (
    <div className="flex items-center justify-between">
      <span className="text-sm text-muted-foreground">{label}</span>
      <div className="flex items-center space-x-2">
        <div 
          className={cn(
            "w-2 h-2 rounded-full",
            status ? "bg-success" : "bg-muted-foreground",
            pulse && status && "animate-pulse"
          )}
        />
        <span className={cn(
          "text-xs font-medium",
          status ? "text-success" : "text-muted-foreground"
        )}>
          {status ? "Active" : "Inactive"}
        </span>
      </div>
    </div>
  );
}
