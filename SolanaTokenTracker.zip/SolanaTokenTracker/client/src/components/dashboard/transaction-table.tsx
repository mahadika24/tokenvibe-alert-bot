import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useQuery } from "@tanstack/react-query";
import { ArrowDown, ArrowUp, Copy, Download } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { useState } from "react";

export default function TransactionTable() {
  const { toast } = useToast();
  const [timeRange, setTimeRange] = useState("today");

  const { data: transactions, isLoading } = useQuery({
    queryKey: ['/api/transactions'],
    refetchInterval: 30000, // Refresh every 30 seconds
  });

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast({
      title: "Copied",
      description: "Transaction hash copied to clipboard.",
    });
  };

  const exportData = () => {
    // Mock export functionality
    toast({
      title: "Export started",
      description: "Transaction data export will begin shortly.",
    });
  };

  if (isLoading) {
    return (
      <Card className="bg-surface border-border mt-8">
        <CardHeader className="border-b border-border">
          <CardTitle className="text-lg font-semibold text-foreground">Recent Transactions</CardTitle>
        </CardHeader>
        <CardContent className="p-6">
          <div className="space-y-4">
            {Array.from({ length: 5 }).map((_, i) => (
              <div key={i} className="animate-pulse">
                <div className="h-12 bg-muted rounded"></div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="bg-surface border-border mt-8">
      <CardHeader className="border-b border-border">
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg font-semibold text-foreground">Recent Transactions</CardTitle>
          <div className="flex items-center space-x-3">
            <Select value={timeRange} onValueChange={setTimeRange}>
              <SelectTrigger className="w-32">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="today">Today</SelectItem>
                <SelectItem value="week">This Week</SelectItem>
                <SelectItem value="month">This Month</SelectItem>
                <SelectItem value="all">All Time</SelectItem>
              </SelectContent>
            </Select>
            <Button variant="outline" size="sm" onClick={exportData}>
              <Download className="mr-1 h-4 w-4" />
              Export
            </Button>
          </div>
        </div>
      </CardHeader>
      <div className="overflow-x-auto">
        <table className="w-full">
          <thead className="bg-muted">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">
                Type
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">
                Amount
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">
                SOL Value
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">
                Transaction Hash
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">
                Timestamp
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">
                Status
              </th>
            </tr>
          </thead>
          <tbody className="bg-surface divide-y divide-border">
            {transactions && transactions.length > 0 ? (
              transactions.map((tx: any) => (
                <TransactionRow key={tx.id} transaction={tx} onCopyHash={copyToClipboard} />
              ))
            ) : (
              <tr>
                <td colSpan={6} className="px-6 py-8 text-center text-muted-foreground">
                  No transactions found
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
      <div className="px-6 py-4 border-t border-border">
        <div className="flex items-center justify-between">
          <p className="text-sm text-muted-foreground">
            Showing {transactions?.length || 0} results
          </p>
          <div className="flex space-x-2">
            <Button variant="outline" size="sm" disabled>
              Previous
            </Button>
            <Button variant="outline" size="sm">
              Next
            </Button>
          </div>
        </div>
      </div>
    </Card>
  );
}

interface TransactionRowProps {
  transaction: any;
  onCopyHash: (hash: string) => void;
}

function TransactionRow({ transaction, onCopyHash }: TransactionRowProps) {
  const isBuyBack = transaction.type === 'buy_back';
  
  return (
    <tr className="hover:bg-muted/50">
      <td className="px-6 py-4 whitespace-nowrap">
        <div className="flex items-center">
          <div className={`w-8 h-8 rounded-full flex items-center justify-center mr-3 ${
            isBuyBack ? 'bg-green-100 dark:bg-green-950' : 'bg-orange-100 dark:bg-orange-950'
          }`}>
            {isBuyBack ? (
              <ArrowDown className="text-success text-sm" />
            ) : (
              <ArrowUp className="text-warning text-sm" />
            )}
          </div>
          <span className="text-sm font-medium text-foreground">
            {isBuyBack ? 'Buy-back' : 'Token Out'}
          </span>
        </div>
      </td>
      <td className="px-6 py-4 whitespace-nowrap text-sm text-foreground font-mono">
        {Number(transaction.amount).toLocaleString()} GP
      </td>
      <td className="px-6 py-4 whitespace-nowrap text-sm text-foreground font-mono">
        {transaction.solValue ? `${Number(transaction.solValue).toFixed(1)} SOL` : '-'}
      </td>
      <td className="px-6 py-4 whitespace-nowrap">
        <div className="flex items-center">
          <span className="text-sm text-foreground font-mono">
            {transaction.transactionHash.slice(0, 8)}...{transaction.transactionHash.slice(-4)}
          </span>
          <Button
            variant="ghost"
            size="sm"
            className="ml-2 h-6 w-6 p-0"
            onClick={() => onCopyHash(transaction.transactionHash)}
          >
            <Copy className="h-3 w-3" />
          </Button>
        </div>
      </td>
      <td className="px-6 py-4 whitespace-nowrap text-sm text-muted-foreground">
        {new Date(transaction.timestamp).toLocaleString()}
      </td>
      <td className="px-6 py-4 whitespace-nowrap">
        <Badge 
          variant={transaction.status === 'confirmed' ? 'default' : 'secondary'}
          className={transaction.status === 'confirmed' ? 'bg-success text-white' : ''}
        >
          {transaction.status.charAt(0).toUpperCase() + transaction.status.slice(1)}
        </Badge>
      </td>
    </tr>
  );
}
