# Token Monitoring System

## Overview

This is a comprehensive Solana token monitoring system that tracks buy-back transactions for specific tokens and provides real-time notifications through Telegram and Notion. The application features a React-based dashboard for monitoring token activity, configuring settings, and managing bot integrations.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Styling**: TailwindCSS with Radix UI components (shadcn/ui)
- **Routing**: Wouter for client-side routing
- **State Management**: TanStack Query for server state management
- **Build Tool**: Vite with custom configuration for development and production

### Backend Architecture
- **Runtime**: Node.js with Express.js
- **Language**: TypeScript with ES modules
- **Database**: PostgreSQL with Drizzle ORM
- **Real-time Communication**: WebSocket server for live updates
- **External Integrations**: Solana blockchain, Telegram Bot API, Notion API

### Bot System
- **Language**: Python with asyncio for concurrent operations
- **Components**: Telegram bot, Notion bot, Solana monitor
- **Communication**: HTTP API communication with Node.js backend

## Key Components

### Database Schema (Drizzle ORM)
- **Users**: Authentication and user management
- **Monitoring Configs**: Wallet and token monitoring settings
- **Transactions**: Blockchain transaction records
- **Bot Configs**: Telegram and Notion bot configurations
- **Notifications**: Message delivery tracking
- **Daily Stats**: Aggregated monitoring statistics

### Dashboard Components
- **Stats Cards**: Real-time statistics display
- **Transaction Table**: Historical transaction data
- **Configuration Panel**: Monitoring settings management
- **Bot Settings**: Telegram and Notion integration setup
- **Real-time Activity**: Live transaction monitoring

### Bot Services
- **Solana Monitor**: Tracks blockchain transactions for specified wallets
- **Telegram Bot**: Sends notifications to configured Telegram chats
- **Notion Bot**: Creates reports and updates in Notion databases

## Data Flow

1. **Monitoring Setup**: Users configure wallet addresses and token settings through the dashboard
2. **Blockchain Monitoring**: Python Solana monitor polls the blockchain for new transactions
3. **Transaction Processing**: Detected transactions are stored in PostgreSQL database
4. **Real-time Updates**: WebSocket broadcasts new transactions to connected dashboard clients
5. **Notifications**: Bot services send alerts via Telegram and create Notion reports
6. **Dashboard Display**: React frontend displays live statistics and transaction history

## External Dependencies

### Blockchain Integration
- **Solana RPC**: Mainnet connection for transaction monitoring
- **Web3.js**: Solana blockchain interaction library

### Notification Services
- **Telegram Bot API**: Real-time message delivery
- **Notion API**: Database creation and report generation

### Database
- **PostgreSQL**: Primary data storage with Neon serverless hosting
- **Drizzle ORM**: Type-safe database operations

### UI/UX
- **Radix UI**: Accessible component primitives
- **TailwindCSS**: Utility-first styling framework
- **Lucide Icons**: Consistent iconography

## Deployment Strategy

### Development Environment
- **Node.js**: Backend server with hot reload
- **Vite**: Frontend development server with HMR
- **Python**: Bot services with auto-restart capabilities

### Production Build
- **Frontend**: Vite builds optimized React bundle
- **Backend**: ESBuild creates Node.js production bundle
- **Bots**: Python services run as background processes

### Environment Configuration
- Database credentials via DATABASE_URL
- Telegram bot token and chat ID
- Notion integration secret and page URL
- Solana RPC endpoint and wallet addresses
- Polling intervals and alert thresholds

### Monitoring & Logging
- WebSocket connection health monitoring
- Bot service status tracking
- Transaction processing error handling
- Real-time dashboard status indicators