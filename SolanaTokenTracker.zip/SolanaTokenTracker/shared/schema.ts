import { pgTable, text, serial, integer, boolean, timestamp, decimal } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const monitoringConfigs = pgTable("monitoring_configs", {
  id: serial("id").primaryKey(),
  walletAddress: text("wallet_address").notNull(),
  tokenAddress: text("token_address").notNull(),
  tokenSymbol: text("token_symbol").notNull().default("GP"),
  pollingInterval: integer("polling_interval").notNull().default(1), // minutes
  alertThreshold: integer("alert_threshold").notNull().default(60), // minutes
  isActive: boolean("is_active").notNull().default(true),
  useAlternativeRpc: boolean("use_alternative_rpc").notNull().default(false),
  rpcEndpoint: text("rpc_endpoint").default("https://api.mainnet-beta.solana.com"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const transactions = pgTable("transactions", {
  id: serial("id").primaryKey(),
  configId: integer("config_id").references(() => monitoringConfigs.id),
  transactionHash: text("transaction_hash").notNull().unique(),
  type: text("type").notNull(), // 'buy_back' | 'token_out'
  amount: decimal("amount", { precision: 20, scale: 8 }).notNull(),
  solValue: decimal("sol_value", { precision: 15, scale: 8 }),
  timestamp: timestamp("timestamp").notNull(),
  status: text("status").notNull().default("confirmed"), // 'confirmed' | 'pending' | 'failed'
  createdAt: timestamp("created_at").defaultNow(),
});

export const botConfigs = pgTable("bot_configs", {
  id: serial("id").primaryKey(),
  type: text("type").notNull(), // 'telegram' | 'notion'
  isEnabled: boolean("is_enabled").notNull().default(true),
  config: text("config").notNull(), // JSON string of bot-specific config
  notificationSettings: text("notification_settings").default("{}"), // JSON for notification preferences
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const notifications = pgTable("notifications", {
  id: serial("id").primaryKey(),
  type: text("type").notNull(), // 'buy_back' | 'alert' | 'token_out'
  message: text("message").notNull(),
  platform: text("platform").notNull(), // 'telegram' | 'notion'
  status: text("status").notNull().default("pending"), // 'pending' | 'sent' | 'failed'
  transactionId: integer("transaction_id").references(() => transactions.id),
  sentAt: timestamp("sent_at"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const dailyStats = pgTable("daily_stats", {
  id: serial("id").primaryKey(),
  date: text("date").notNull(), // YYYY-MM-DD format
  configId: integer("config_id").references(() => monitoringConfigs.id),
  totalBuybacks: integer("total_buybacks").notNull().default(0),
  totalAmount: decimal("total_amount", { precision: 20, scale: 8 }).notNull().default("0"),
  totalSolVolume: decimal("total_sol_volume", { precision: 15, scale: 8 }).notNull().default("0"),
  tokensOut: decimal("tokens_out", { precision: 20, scale: 8 }).notNull().default("0"),
  avgFrequency: decimal("avg_frequency", { precision: 10, scale: 2 }).notNull().default("0"), // minutes
});

// Insert schemas
export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertMonitoringConfigSchema = createInsertSchema(monitoringConfigs).omit({
  id: true,
  createdAt: true,
});

export const insertTransactionSchema = createInsertSchema(transactions).omit({
  id: true,
  createdAt: true,
});

export const insertBotConfigSchema = createInsertSchema(botConfigs).omit({
  id: true,
  updatedAt: true,
});

export const insertNotificationSchema = createInsertSchema(notifications).omit({
  id: true,
  sentAt: true,
  createdAt: true,
});

export const insertDailyStatsSchema = createInsertSchema(dailyStats).omit({
  id: true,
});

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type MonitoringConfig = typeof monitoringConfigs.$inferSelect;
export type InsertMonitoringConfig = z.infer<typeof insertMonitoringConfigSchema>;

export type Transaction = typeof transactions.$inferSelect;
export type InsertTransaction = z.infer<typeof insertTransactionSchema>;

export type BotConfig = typeof botConfigs.$inferSelect;
export type InsertBotConfig = z.infer<typeof insertBotConfigSchema>;

export type Notification = typeof notifications.$inferSelect;
export type InsertNotification = z.infer<typeof insertNotificationSchema>;

export type DailyStats = typeof dailyStats.$inferSelect;
export type InsertDailyStats = z.infer<typeof insertDailyStatsSchema>;

// API Response types
export interface DashboardStats {
  dailyBuybacks: string;
  dailySol: string;
  avgFrequency: string;
  weeklyOutflow: string;
  totalBuybacks: number;
  totalVolume: string;
}

export interface RealtimeTransaction {
  id: number;
  type: string;
  amount: string;
  solAmount?: string;
  timestamp: string;
  hash: string;
}

export interface BotStatus {
  telegram: boolean;
  notion: boolean;
  monitoring: boolean;
}
