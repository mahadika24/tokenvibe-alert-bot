import type { Express } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer } from "ws";
import { storage } from "./storage";
import { 
  insertMonitoringConfigSchema, 
  insertBotConfigSchema,
  insertTransactionSchema 
} from "@shared/schema";
import { setupWebSocket } from "./services/websocket";

export async function registerRoutes(app: Express): Promise<Server> {
  const httpServer = createServer(app);
  
  // Setup WebSocket for real-time updates
  const wss = new WebSocketServer({ server: httpServer });
  setupWebSocket(wss);

  // Dashboard Stats API
  app.get("/api/dashboard/stats", async (req, res) => {
    try {
      const stats = await storage.getDashboardStats();
      res.json(stats);
    } catch (error) {
      console.error("Error fetching dashboard stats:", error);
      res.status(500).json({ message: "Failed to fetch dashboard stats" });
    }
  });

  // Recent Transactions API
  app.get("/api/dashboard/transactions", async (req, res) => {
    try {
      const limit = parseInt(req.query.limit as string) || 10;
      const transactions = await storage.getRecentTransactions(limit);
      res.json(transactions);
    } catch (error) {
      console.error("Error fetching recent transactions:", error);
      res.status(500).json({ message: "Failed to fetch recent transactions" });
    }
  });

  // Bot Status API
  app.get("/api/dashboard/bot-status", async (req, res) => {
    try {
      const status = await storage.getBotStatus();
      res.json(status);
    } catch (error) {
      console.error("Error fetching bot status:", error);
      res.status(500).json({ message: "Failed to fetch bot status" });
    }
  });

  // Monitoring Configs APIs
  app.get("/api/monitoring/configs", async (req, res) => {
    try {
      const configs = await storage.getMonitoringConfigs();
      res.json(configs);
    } catch (error) {
      console.error("Error fetching monitoring configs:", error);
      res.status(500).json({ message: "Failed to fetch monitoring configs" });
    }
  });

  app.post("/api/monitoring/configs", async (req, res) => {
    try {
      const validatedData = insertMonitoringConfigSchema.parse(req.body);
      const config = await storage.createMonitoringConfig(validatedData);
      res.status(201).json(config);
    } catch (error) {
      console.error("Error creating monitoring config:", error);
      res.status(400).json({ message: "Invalid monitoring config data" });
    }
  });

  app.put("/api/monitoring/configs/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const validatedData = insertMonitoringConfigSchema.partial().parse(req.body);
      const config = await storage.updateMonitoringConfig(id, validatedData);
      
      if (!config) {
        return res.status(404).json({ message: "Monitoring config not found" });
      }
      
      res.json(config);
    } catch (error) {
      console.error("Error updating monitoring config:", error);
      res.status(400).json({ message: "Invalid monitoring config data" });
    }
  });

  app.delete("/api/monitoring/configs/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const deleted = await storage.deleteMonitoringConfig(id);
      
      if (!deleted) {
        return res.status(404).json({ message: "Monitoring config not found" });
      }
      
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting monitoring config:", error);
      res.status(500).json({ message: "Failed to delete monitoring config" });
    }
  });

  // Bot Configs APIs
  app.get("/api/bots/configs", async (req, res) => {
    try {
      const configs = await storage.getBotConfigs();
      res.json(configs);
    } catch (error) {
      console.error("Error fetching bot configs:", error);
      res.status(500).json({ message: "Failed to fetch bot configs" });
    }
  });

  app.post("/api/bots/configs", async (req, res) => {
    try {
      const { type, isEnabled, config, notificationSettings } = req.body;
      
      const botConfig = await storage.upsertBotConfig({
        type,
        isEnabled: isEnabled ?? true,
        config: config || "{}",
        notificationSettings: notificationSettings || "{}"
      });
      
      res.json(botConfig);
    } catch (error) {
      console.error("Error saving bot config:", error);
      res.status(500).json({ error: "Failed to save bot configuration" });
    }
  });

  // Monitoring configuration routes
  app.get("/api/monitoring/config", async (req, res) => {
    try {
      const configs = await storage.getMonitoringConfigs();
      res.json(configs[0] || null);
    } catch (error) {
      console.error("Error fetching monitoring config:", error);
      res.status(500).json({ error: "Failed to fetch monitoring configuration" });
    }
  });

  app.post("/api/monitoring/config", async (req, res) => {
    try {
      const configData = req.body;
      const config = await storage.createMonitoringConfig(configData);
      res.json(config);
    } catch (error) {
      console.error("Error saving monitoring config:", error);
      res.status(500).json({ error: "Failed to save monitoring configuration" });
    }
  });

  app.post("/api/monitoring/test-connection", async (req, res) => {
    try {
      const { apiType } = req.body;
      
      let testResult = false;
      
      switch (apiType) {
        case 'solscan':
          try {
            const response = await fetch('https://api.solscan.io/chaininfo', {
              headers: { 'User-Agent': 'TokenMonitor/1.0' }
            });
            testResult = response.ok;
          } catch {
            testResult = false;
          }
          break;
          
        case 'helius':
          try {
            const heliusKey = process.env.HELIUS_API_KEY;
            if (!heliusKey) {
              testResult = false;
              break;
            }
            const response = await fetch(`https://mainnet.helius-rpc.com/?api-key=${heliusKey}`, {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                jsonrpc: '2.0',
                id: 1,
                method: 'getHealth'
              })
            });
            testResult = response.ok;
          } catch {
            testResult = false;
          }
          break;
          
        default:
          testResult = false;
      }
      
      res.json({ success: testResult, apiType });
    } catch (error) {
      console.error("Error testing API connection:", error);
      res.status(500).json({ error: "Failed to test API connection" });
    }
  });

  // Test Bot Connections
  app.post("/api/bots/test/:type", async (req, res) => {
    try {
      const { type } = req.params;
      const { config } = req.body;

      if (type === "telegram") {
        // Test Telegram bot connection
        const response = await fetch(`https://api.telegram.org/bot${config.botToken}/getMe`);
        const data = await response.json();
        
        if (data.ok) {
          res.json({ success: true, message: "Telegram bot connection successful" });
        } else {
          res.status(400).json({ success: false, message: "Invalid Telegram bot token" });
        }
      } else if (type === "notion") {
        // Test Notion connection
        try {
          const response = await fetch("https://api.notion.com/v1/users/me", {
            headers: {
              "Authorization": `Bearer ${config.integrationSecret}`,
              "Notion-Version": "2022-06-28"
            }
          });
          
          if (response.ok) {
            res.json({ success: true, message: "Notion connection successful" });
          } else {
            res.status(400).json({ success: false, message: "Invalid Notion integration secret" });
          }
        } catch (error) {
          res.status(400).json({ success: false, message: "Failed to connect to Notion" });
        }
      } else {
        res.status(400).json({ success: false, message: "Invalid bot type" });
      }
    } catch (error) {
      console.error("Error testing bot connection:", error);
      res.status(500).json({ success: false, message: "Failed to test bot connection" });
    }
  });

  // Transactions APIs
  app.get("/api/transactions", async (req, res) => {
    try {
      const limit = parseInt(req.query.limit as string) || 50;
      const offset = parseInt(req.query.offset as string) || 0;
      const transactions = await storage.getTransactions(limit, offset);
      res.json(transactions);
    } catch (error) {
      console.error("Error fetching transactions:", error);
      res.status(500).json({ message: "Failed to fetch transactions" });
    }
  });

  app.post("/api/transactions", async (req, res) => {
    try {
      const validatedData = insertTransactionSchema.parse(req.body);
      const transaction = await storage.createTransaction(validatedData);
      
      // Broadcast to WebSocket clients
      wss.clients.forEach(client => {
        if (client.readyState === 1) { // WebSocket.OPEN
          client.send(JSON.stringify({
            type: 'new_transaction',
            data: transaction
          }));
        }
      });
      
      res.status(201).json(transaction);
    } catch (error) {
      console.error("Error creating transaction:", error);
      res.status(400).json({ message: "Invalid transaction data" });
    }
  });

  // System Health Check
  app.get("/api/health", async (req, res) => {
    try {
      const botStatus = await storage.getBotStatus();
      const configs = await storage.getMonitoringConfigs();
      
      res.json({
        status: "healthy",
        timestamp: new Date().toISOString(),
        bots: botStatus,
        activeConfigs: configs.filter(c => c.isActive).length,
        totalConfigs: configs.length
      });
    } catch (error) {
      console.error("Health check failed:", error);
      res.status(500).json({ status: "unhealthy", message: "System health check failed" });
    }
  });

  return httpServer;
}
