import { Client } from "@notionhq/client";
import { storage } from "../storage";

export class NotionBot {
  private notion: Client | null = null;
  private pageId: string | null = null;
  private databaseId: string | null = null;
  private isEnabled: boolean = false;
  private reportSchedule: string[] = ["06:00", "12:00", "17:00", "24:00"];

  constructor() {
    this.initializeConfig();
  }

  private async initializeConfig() {
    try {
      const config = await storage.getBotConfig("notion");
      if (config) {
        const parsedConfig = JSON.parse(config.config);
        this.notion = new Client({ auth: parsedConfig.integrationSecret });
        this.pageId = this.extractPageIdFromUrl(parsedConfig.pageUrl);
        this.isEnabled = config.isEnabled;
        this.reportSchedule = parsedConfig.schedule || this.reportSchedule;
        
        if (this.isEnabled) {
          await this.setupDatabase();
        }
      }
    } catch (error) {
      console.error("Error initializing Notion bot config:", error);
    }
  }

  async updateConfig(integrationSecret: string, pageUrl: string, enabled: boolean, schedule?: string[]) {
    this.notion = new Client({ auth: integrationSecret });
    this.pageId = this.extractPageIdFromUrl(pageUrl);
    this.isEnabled = enabled;
    if (schedule) this.reportSchedule = schedule;

    await storage.upsertBotConfig({
      type: "notion",
      isEnabled: enabled,
      config: JSON.stringify({ 
        integrationSecret, 
        pageUrl, 
        schedule: this.reportSchedule 
      })
    });

    if (enabled) {
      await this.setupDatabase();
    }
  }

  private extractPageIdFromUrl(pageUrl: string): string {
    const match = pageUrl.match(/([a-f0-9]{32})(?:[?#]|$)/i);
    if (match && match[1]) {
      return match[1];
    }
    throw new Error("Failed to extract page ID from URL");
  }

  private async setupDatabase() {
    if (!this.notion || !this.pageId) return;

    try {
      // Check if database already exists
      const databases = await this.getChildDatabases();
      const existingDb = databases.find(db => 
        db.title && Array.isArray(db.title) && 
        db.title[0]?.plain_text?.toLowerCase() === "token monitoring reports"
      );

      if (existingDb) {
        this.databaseId = existingDb.id;
        return;
      }

      // Create new database
      const database = await this.notion.databases.create({
        parent: {
          type: "page_id",
          page_id: this.pageId
        },
        title: [
          {
            type: "text",
            text: {
              content: "Token Monitoring Reports"
            }
          }
        ],
        properties: {
          "Report Date": {
            title: {}
          },
          "Total Buybacks": {
            number: {}
          },
          "Daily Volume (SOL)": {
            number: {}
          },
          "Avg Frequency (min)": {
            number: {}
          },
          "Tokens Out Today": {
            number: {}
          },
          "Tokens Out Week": {
            number: {}
          },
          "Tokens Out Total": {
            number: {}
          },
          "Report Type": {
            select: {
              options: [
                { name: "Daily", color: "blue" },
                { name: "Alert", color: "red" },
                { name: "Summary", color: "green" }
              ]
            }
          },
          "Created At": {
            date: {}
          }
        }
      });

      this.databaseId = database.id;
      console.log("Notion database created successfully");
    } catch (error) {
      console.error("Error setting up Notion database:", error);
    }
  }

  private async getChildDatabases() {
    if (!this.notion || !this.pageId) return [];

    try {
      const response = await this.notion.blocks.children.list({
        block_id: this.pageId,
      });

      const databases = [];
      for (const block of response.results) {
        if (block.type === "child_database") {
          const databaseInfo = await this.notion.databases.retrieve({
            database_id: block.id,
          });
          databases.push(databaseInfo);
        }
      }

      return databases;
    } catch (error) {
      console.error("Error getting child databases:", error);
      return [];
    }
  }

  async createReport(reportType: "scheduled" | "alert", data?: any) {
    if (!this.notion || !this.databaseId || !this.isEnabled) return;

    try {
      const now = new Date();
      const today = now.toISOString().split('T')[0];

      // Get statistics for the report
      const stats = await storage.getDashboardStats();
      const todayStats = await storage.getDailyStats(today);
      const weekStats = await this.getWeeklyStats();

      const reportTitle = reportType === "scheduled" 
        ? `Daily Report - ${today}`
        : `Alert Report - ${now.toISOString()}`;

      await this.notion.pages.create({
        parent: {
          database_id: this.databaseId
        },
        properties: {
          "Report Date": {
            title: [
              {
                type: "text",
                text: {
                  content: reportTitle
                }
              }
            ]
          },
          "Total Buybacks": {
            number: parseInt(stats.dailyBuybacks.replace(/[^\d]/g, '')) || 0
          },
          "Daily Volume (SOL)": {
            number: parseFloat(stats.dailySol.replace(' SOL', '')) || 0
          },
          "Avg Frequency (min)": {
            number: parseFloat(stats.avgFrequency.replace(' min', '')) || 0
          },
          "Tokens Out Today": {
            number: todayStats.reduce((sum, s) => sum + Number(s.tokensOut), 0)
          },
          "Tokens Out Week": {
            number: parseInt(stats.weeklyOutflow.replace(/[^\d]/g, '')) * 1000 || 0
          },
          "Tokens Out Total": {
            number: weekStats.totalOutflow
          },
          "Report Type": {
            select: {
              name: reportType === "scheduled" ? "Daily" : "Alert"
            }
          },
          "Created At": {
            date: {
              start: now.toISOString()
            }
          }
        },
        children: [
          {
            object: "block",
            type: "heading_2",
            heading_2: {
              rich_text: [
                {
                  type: "text",
                  text: {
                    content: `Token Monitoring Report - ${today}`
                  }
                }
              ]
            }
          },
          {
            object: "block",
            type: "paragraph",
            paragraph: {
              rich_text: [
                {
                  type: "text",
                  text: {
                    content: `Generated on: ${now.toLocaleString('id-ID')}\n\nDaily Summary:\n• Total buy-back transactions: ${stats.totalBuybacks}\n• Daily volume: ${stats.dailySol}\n• Average frequency: ${stats.avgFrequency}\n• Tokens transferred out today: ${todayStats.reduce((sum, s) => sum + Number(s.tokensOut), 0).toLocaleString()}\n• Tokens transferred out this week: ${stats.weeklyOutflow}\n• Total tokens transferred out: ${weekStats.totalOutflow.toLocaleString()}`
                  }
                }
              ]
            }
          }
        ]
      });

      console.log(`Notion report created: ${reportTitle}`);
    } catch (error) {
      console.error("Error creating Notion report:", error);
    }
  }

  private async getWeeklyStats() {
    const weekAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString().split('T')[0];
    const allStats = await storage.getDailyStats(weekAgo);
    
    return {
      totalOutflow: allStats.reduce((sum, s) => sum + Number(s.tokensOut), 0)
    };
  }

  async processPendingNotifications() {
    if (!this.isEnabled) return;

    try {
      const notifications = await storage.getPendingNotifications();
      const notionNotifications = notifications.filter(n => n.platform === "notion");

      for (const notification of notionNotifications) {
        await this.createReport("alert", { message: notification.message });
        await storage.updateNotificationStatus(notification.id, "sent", new Date());
      }
    } catch (error) {
      console.error("Error processing pending Notion notifications:", error);
    }
  }

  async start() {
    console.log("Starting Notion bot service...");
    
    // Process notifications every 30 seconds
    setInterval(() => {
      this.processPendingNotifications();
    }, 30000);

    // Schedule reports
    this.scheduleReports();
  }

  private scheduleReports() {
    // Check every minute if it's time for a scheduled report
    setInterval(() => {
      const now = new Date();
      const currentTime = now.toTimeString().slice(0, 5); // HH:MM format

      if (this.reportSchedule.includes(currentTime)) {
        this.createReport("scheduled");
      }
    }, 60000); // Check every minute
  }
}

// Export singleton instance
export const notionBot = new NotionBot();
