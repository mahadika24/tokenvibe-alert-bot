import { storage } from "../storage";
import type { InsertTransaction } from "@shared/schema";

export class SolscanMonitor {
  private apiKey: string;
  private walletAddress: string;
  private pollingInterval: number = 60000; // 1 minute
  private isRunning: boolean = false;
  private processedTxs: Set<string> = new Set();

  constructor() {
    this.apiKey = process.env.SOLSCAN_API_KEY || '';
    this.walletAddress = process.env.WALLET_ADDRESS || 'QPKJCvwZNMLnShg6nrEnVPt32u9j5Psdufy2cBoiSi1';
  }

  async start() {
    if (this.isRunning) {
      console.log("Solscan monitor is already running");
      return;
    }

    this.isRunning = true;
    console.log("Starting Solscan monitor...");
    
    this.monitorLoop();
  }

  async stop() {
    this.isRunning = false;
    console.log("Stopping Solscan monitor...");
  }

  private async monitorLoop() {
    while (this.isRunning) {
      try {
        await this.checkTransactions();
        await this.sleep(this.pollingInterval);
      } catch (error) {
        console.error("Error in Solscan monitoring loop:", error);
        await this.sleep(5000);
      }
    }
  }

  private async checkTransactions() {
    try {
      // Use alternative API endpoints for Solana data
      const endpoints = [
        `https://api.solscan.io/account/transaction?address=${this.walletAddress}&limit=20`,
        `https://api.helius-rpc.com/v0/addresses/${this.walletAddress}/transactions?api-key=${process.env.HELIUS_API_KEY || 'demo'}`,
        `https://api.solana.fm/v1/addresses/${this.walletAddress}/transactions?cluster=mainnet-beta`
      ];

      let response = null;
      
      for (const endpoint of endpoints) {
        try {
          response = await fetch(endpoint, {
            headers: {
              'User-Agent': 'TokenMonitor/1.0',
              'Accept': 'application/json'
            }
          });
          
          if (response.ok) {
            break;
          }
        } catch (error) {
          console.log(`Failed to fetch from ${endpoint.split('?')[0]}, trying next...`);
          continue;
        }
      }

      if (!response || !response.ok) {
        console.log(`All API endpoints failed, will retry next cycle`);
        return;
      }

      const data = await response.json();
      
      // Handle different API response structures
      const transactions = data.data || data.result || data || [];
      
      if (Array.isArray(transactions)) {
        for (const tx of transactions) {
          if (this.processedTxs.has(tx.signature)) {
            continue;
          }

          const analysis = this.analyzeTransaction(tx);
          if (analysis) {
            await this.saveTransaction(analysis);
            console.log(`New ${analysis.type} detected via Solscan: ${tx.signature.slice(0, 8)}...`);
          }

          this.processedTxs.add(tx.signature);
        }
      }

      // Keep only last 1000 processed transactions to prevent memory issues
      if (this.processedTxs.size > 1000) {
        const txArray = Array.from(this.processedTxs);
        this.processedTxs = new Set(txArray.slice(-500));
      }

    } catch (error) {
      console.error("Error checking Solscan transactions:", error);
    }
  }

  private analyzeTransaction(tx: any): { type: string; amount: number; solValue?: number; signature: string; timestamp: Date } | null {
    try {
      // Check for SOL balance changes
      const solChange = tx.lamportChange || 0;
      const timestamp = new Date(tx.blockTime * 1000);

      if (solChange < -1000000) { // SOL decreased (spent) - likely buy-back
        const solAmount = Math.abs(solChange) / 1e9;
        const estimatedGpAmount = solAmount * 1000000; // Rough estimation
        
        return {
          type: 'buy_back',
          amount: estimatedGpAmount,
          solValue: solAmount,
          signature: tx.signature,
          timestamp
        };
      } else if (solChange > 1000000) { // SOL increased - might be token sale
        const solAmount = solChange / 1e9;
        const estimatedGpAmount = solAmount * 500000;
        
        return {
          type: 'token_out',
          amount: estimatedGpAmount,
          signature: tx.signature,
          timestamp
        };
      }

      return null;
    } catch (error) {
      console.error("Error analyzing transaction:", error);
      return null;
    }
  }

  private async saveTransaction(analysis: any) {
    try {
      const newTransaction: InsertTransaction = {
        configId: 1,
        transactionHash: analysis.signature,
        type: analysis.type,
        amount: analysis.amount.toString(),
        solValue: analysis.solValue?.toString(),
        timestamp: analysis.timestamp,
        status: "confirmed"
      };

      await storage.createTransaction(newTransaction);

      // Create notification
      await storage.createNotification({
        type: analysis.type,
        message: analysis.type === 'buy_back' 
          ? `🔥 Buy-back Detected! 💰 Jumlah: ${analysis.amount.toLocaleString()} GP`
          : `🚨 Pergerakan Token! Token GP keluar: ${analysis.amount.toLocaleString()} GP`,
        platform: "telegram",
        status: "pending"
      });

    } catch (error) {
      console.error("Error saving transaction:", error);
    }
  }

  private sleep(ms: number): Promise<void> {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
}

export const solscanMonitor = new SolscanMonitor();