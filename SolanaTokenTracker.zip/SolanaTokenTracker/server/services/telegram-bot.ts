import { storage } from "../storage";

export class TelegramBot {
  private botToken: string | null = null;
  private chatId: string | null = null;
  private isEnabled: boolean = false;
  private lastActivityCheck: Date = new Date();

  constructor() {
    this.initializeConfig();
  }

  private async initializeConfig() {
    try {
      const config = await storage.getBotConfig("telegram");
      if (config) {
        const parsedConfig = JSON.parse(config.config);
        this.botToken = parsedConfig.botToken;
        this.chatId = parsedConfig.chatId;
        this.isEnabled = config.isEnabled;
      }
    } catch (error) {
      console.error("Error initializing Telegram bot config:", error);
    }
  }

  async updateConfig(botToken: string, chatId: string, enabled: boolean) {
    this.botToken = botToken;
    this.chatId = chatId;
    this.isEnabled = enabled;

    await storage.upsertBotConfig({
      type: "telegram",
      isEnabled: enabled,
      config: JSON.stringify({ botToken, chatId })
    });
  }

  async sendMessage(message: string): Promise<boolean> {
    if (!this.isEnabled || !this.botToken || !this.chatId) {
      console.log("Telegram bot not properly configured or disabled");
      return false;
    }

    try {
      const response = await fetch(`https://api.telegram.org/bot${this.botToken}/sendMessage`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          chat_id: this.chatId,
          text: message,
          parse_mode: "HTML"
        })
      });

      const data = await response.json();
      
      if (data.ok) {
        console.log("Telegram message sent successfully");
        return true;
      } else {
        console.error("Failed to send Telegram message:", data.description);
        return false;
      }
    } catch (error) {
      console.error("Error sending Telegram message:", error);
      return false;
    }
  }

  async processPendingNotifications() {
    if (!this.isEnabled) return;

    try {
      const notifications = await storage.getPendingNotifications();
      const telegramNotifications = notifications.filter(n => n.platform === "telegram");

      for (const notification of telegramNotifications) {
        const success = await this.sendMessage(notification.message);
        await storage.updateNotificationStatus(
          notification.id,
          success ? "sent" : "failed",
          success ? new Date() : undefined
        );
      }
    } catch (error) {
      console.error("Error processing pending Telegram notifications:", error);
    }
  }

  async checkInactivityAlert() {
    try {
      const configs = await storage.getMonitoringConfigs();
      
      for (const config of configs.filter(c => c.isActive)) {
        const recentTransactions = await storage.getTransactionsByConfig(config.id, 1);
        
        if (recentTransactions.length === 0) continue;

        const lastTransaction = recentTransactions[0];
        const now = new Date();
        const timeDiff = now.getTime() - new Date(lastTransaction.timestamp).getTime();
        const minutesDiff = timeDiff / (1000 * 60);

        if (minutesDiff > config.alertThreshold) {
          const alertMessage = `⚠️ Peringatan!\n❌ Tidak ada buy-back selama ${Math.floor(minutesDiff)} menit terakhir.\n🚨 Mohon segera cek aktivitas wallet tim!`;
          
          await this.sendMessage(alertMessage);
          
          // Update last check to avoid spam
          this.lastActivityCheck = now;
        }
      }
    } catch (error) {
      console.error("Error checking inactivity alerts:", error);
    }
  }

  async start() {
    console.log("Starting Telegram bot service...");
    
    // Process notifications every 10 seconds
    setInterval(() => {
      this.processPendingNotifications();
    }, 10000);

    // Check for inactivity alerts every 5 minutes
    setInterval(() => {
      this.checkInactivityAlert();
    }, 5 * 60 * 1000);
  }
}

// Export singleton instance
export const telegramBot = new TelegramBot();
