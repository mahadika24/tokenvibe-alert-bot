import { Connection, PublicKey } from "@solana/web3.js";
import { storage } from "../storage";
import type { InsertTransaction } from "@shared/schema";

export class SolanaMonitor {
  private connection: Connection;
  private isRunning: boolean = false;
  private pollInterval: number = 60000; // 1 minute in milliseconds

  constructor() {
    // Use a reliable Solana RPC endpoint
    this.connection = new Connection(
      process.env.SOLANA_RPC_URL || "https://api.mainnet-beta.solana.com",
      "confirmed"
    );
  }

  async start() {
    if (this.isRunning) {
      console.log("Solana monitor is already running");
      return;
    }

    this.isRunning = true;
    console.log("Starting Solana monitor...");
    
    // Start monitoring loop
    this.monitorLoop();
  }

  async stop() {
    this.isRunning = false;
    console.log("Stopping Solana monitor...");
  }

  private async monitorLoop() {
    while (this.isRunning) {
      try {
        await this.checkTransactions();
        await this.sleep(this.pollInterval);
      } catch (error) {
        console.error("Error in monitoring loop:", error);
        await this.sleep(5000); // Wait 5 seconds before retrying
      }
    }
  }

  private async checkTransactions() {
    try {
      const configs = await storage.getMonitoringConfigs();
      
      for (const config of configs.filter(c => c.isActive)) {
        await this.monitorWallet(config);
      }
    } catch (error) {
      console.error("Error checking transactions:", error);
    }
  }

  private async monitorWallet(config: any) {
    try {
      const walletPublicKey = new PublicKey(config.walletAddress);
      
      // Get recent transactions for the wallet
      const signatures = await this.connection.getSignaturesForAddress(
        walletPublicKey,
        { limit: 10 }
      );

      for (const sigInfo of signatures) {
        // Check if we've already processed this transaction
        const existingTx = await storage.getTransactionByHash(sigInfo.signature);
        if (existingTx) continue;

        // Get transaction details
        const transaction = await this.connection.getTransaction(sigInfo.signature, {
          commitment: "confirmed",
          maxSupportedTransactionVersion: 0
        });

        if (!transaction) continue;

        // Analyze transaction to determine if it's a buy-back or token outflow
        const analysis = await this.analyzeTransaction(transaction, config);
        
        if (analysis) {
          const newTransaction: InsertTransaction = {
            configId: config.id,
            transactionHash: sigInfo.signature,
            type: analysis.type,
            amount: analysis.amount.toString(),
            solValue: analysis.solValue?.toString(),
            timestamp: new Date(sigInfo.blockTime! * 1000),
            status: "confirmed"
          };

          await storage.createTransaction(newTransaction);
          console.log(`New ${analysis.type} transaction detected:`, sigInfo.signature);

          // Create notification
          await this.createNotification(newTransaction, analysis);
        }
      }
    } catch (error) {
      console.error(`Error monitoring wallet ${config.walletAddress}:`, error);
    }
  }

  private async analyzeTransaction(transaction: any, config: any) {
    try {
      // This is a simplified analysis - in reality, you'd need to parse
      // the transaction instructions and account changes to determine
      // if it's a token buy-back or outflow
      
      const preBalances = transaction.meta?.preBalances || [];
      const postBalances = transaction.meta?.postBalances || [];
      
      // Check for SOL balance changes (indicating buy-back)
      const solChange = postBalances[0] - preBalances[0];
      
      if (solChange < 0) {
        // SOL was spent, likely a buy-back
        return {
          type: "buy_back",
          amount: Math.abs(solChange) * 1000000, // Convert from lamports and estimate GP tokens
          solValue: Math.abs(solChange) / 1e9 // Convert lamports to SOL
        };
      } else if (solChange > 0) {
        // SOL was received, might be from token sale
        return {
          type: "token_out",
          amount: solChange * 1000000, // Estimate based on SOL received
          solValue: undefined
        };
      }

      return null;
    } catch (error) {
      console.error("Error analyzing transaction:", error);
      return null;
    }
  }

  private async createNotification(transaction: InsertTransaction, analysis: any) {
    const message = transaction.type === "buy_back" 
      ? `🔥 Buy-back Detected! 💰 Jumlah: ${Number(transaction.amount).toLocaleString()} GP`
      : `🚨 Pergerakan Token! 🔁 Token GP keluar dari wallet: ${Number(transaction.amount).toLocaleString()} GP`;

    // Create Telegram notification
    await storage.createNotification({
      type: transaction.type,
      message,
      platform: "telegram",
      status: "pending",
      transactionId: undefined // Will be set after transaction is created
    });

    // Create Notion notification for significant events
    if (transaction.type === "token_out" || Number(transaction.amount) > 100000) {
      await storage.createNotification({
        type: transaction.type,
        message: `Transaction Alert: ${transaction.type} - ${Number(transaction.amount).toLocaleString()} GP`,
        platform: "notion",
        status: "pending",
        transactionId: undefined
      });
    }
  }

  private sleep(ms: number): Promise<void> {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
}

// Export singleton instance
export const solanaMonitor = new SolanaMonitor();
