import { spawn, ChildProcess } from 'child_process';
import path from 'path';

export class BotManager {
  private botProcess: ChildProcess | null = null;
  private isRunning: boolean = false;

  async start(): Promise<boolean> {
    if (this.isRunning) {
      console.log('Bot manager is already running');
      return true;
    }

    try {
      const botPath = path.resolve(process.cwd(), 'bots');
      const pythonExecutable = process.env.PYTHON_EXECUTABLE || 'python';
      
      console.log('Starting Python bots...');
      
      this.botProcess = spawn(pythonExecutable, ['main.py'], {
        cwd: botPath,
        stdio: ['ignore', 'pipe', 'pipe'],
        env: {
          ...process.env,
          // Pass environment variables to Python bots
          TELEGRAM_BOT_TOKEN: process.env.TELEGRAM_BOT_TOKEN || '',
          TELEGRAM_CHAT_ID: process.env.TELEGRAM_CHAT_ID || '',
          NOTION_INTEGRATION_SECRET: process.env.NOTION_INTEGRATION_SECRET || '',
          NOTION_PAGE_URL: process.env.NOTION_PAGE_URL || '',
          SOLANA_RPC_URL: process.env.SOLANA_RPC_URL || 'https://api.mainnet-beta.solana.com',
          WALLET_ADDRESS: process.env.WALLET_ADDRESS || 'QPKJCvwZNMLnShg6nrEnVPt32u9j5Psdufy2cBoiSi1',
          TOKEN_ADDRESS: process.env.TOKEN_ADDRESS || '',
          POLLING_INTERVAL: process.env.POLLING_INTERVAL || '60',
          API_BASE_URL: `http://localhost:${process.env.PORT || 5000}/api`,
        }
      });

      this.botProcess.stdout?.on('data', (data) => {
        console.log(`[BOTS] ${data.toString().trim()}`);
      });

      this.botProcess.stderr?.on('data', (data) => {
        console.error(`[BOTS ERROR] ${data.toString().trim()}`);
      });

      this.botProcess.on('close', (code) => {
        console.log(`Bot process exited with code ${code}`);
        this.isRunning = false;
        this.botProcess = null;
        
        // Auto-restart on unexpected exit
        if (code !== 0) {
          setTimeout(() => {
            console.log('Attempting to restart bots...');
            this.start();
          }, 5000);
        }
      });

      this.botProcess.on('error', (error) => {
        console.error('Failed to start bot process:', error);
        this.isRunning = false;
        this.botProcess = null;
      });

      this.isRunning = true;
      console.log('Python bots started successfully');
      return true;

    } catch (error) {
      console.error('Error starting bot manager:', error);
      return false;
    }
  }

  async stop(): Promise<void> {
    if (this.botProcess && this.isRunning) {
      console.log('Stopping Python bots...');
      this.botProcess.kill('SIGTERM');
      
      // Force kill after 10 seconds if not stopped gracefully
      setTimeout(() => {
        if (this.botProcess && !this.botProcess.killed) {
          this.botProcess.kill('SIGKILL');
        }
      }, 10000);
      
      this.isRunning = false;
    }
  }

  getStatus(): { running: boolean; pid?: number } {
    return {
      running: this.isRunning,
      pid: this.botProcess?.pid
    };
  }
}

export const botManager = new BotManager();
