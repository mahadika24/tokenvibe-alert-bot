import { 
  users, 
  monitoringConfigs, 
  transactions, 
  botConfigs, 
  notifications, 
  dailyStats,
  type User, 
  type InsertUser,
  type MonitoringConfig,
  type InsertMonitoringConfig,
  type Transaction,
  type InsertTransaction,
  type BotConfig,
  type InsertBotConfig,
  type Notification,
  type InsertNotification,
  type DailyStats,
  type InsertDailyStats,
  type DashboardStats,
  type RealtimeTransaction,
  type BotStatus
} from "@shared/schema";

export interface IStorage {
  // Users
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Monitoring Configs
  getMonitoringConfigs(): Promise<MonitoringConfig[]>;
  getMonitoringConfig(id: number): Promise<MonitoringConfig | undefined>;
  createMonitoringConfig(config: InsertMonitoringConfig): Promise<MonitoringConfig>;
  updateMonitoringConfig(id: number, config: Partial<InsertMonitoringConfig>): Promise<MonitoringConfig | undefined>;
  deleteMonitoringConfig(id: number): Promise<boolean>;

  // Transactions
  getTransactions(limit?: number, offset?: number): Promise<Transaction[]>;
  getTransactionsByConfig(configId: number, limit?: number): Promise<Transaction[]>;
  createTransaction(transaction: InsertTransaction): Promise<Transaction>;
  getTransactionByHash(hash: string): Promise<Transaction | undefined>;

  // Bot Configs
  getBotConfigs(): Promise<BotConfig[]>;
  getBotConfig(type: string): Promise<BotConfig | undefined>;
  upsertBotConfig(config: InsertBotConfig): Promise<BotConfig>;

  // Notifications
  createNotification(notification: InsertNotification): Promise<Notification>;
  getPendingNotifications(): Promise<Notification[]>;
  updateNotificationStatus(id: number, status: string, sentAt?: Date): Promise<void>;

  // Daily Stats
  getDailyStats(date: string, configId?: number): Promise<DailyStats[]>;
  upsertDailyStats(stats: InsertDailyStats): Promise<DailyStats>;

  // Dashboard APIs
  getDashboardStats(configId?: number): Promise<DashboardStats>;
  getRecentTransactions(limit?: number): Promise<RealtimeTransaction[]>;
  getBotStatus(): Promise<BotStatus>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private monitoringConfigs: Map<number, MonitoringConfig>;
  private transactions: Map<number, Transaction>;
  private botConfigs: Map<string, BotConfig>;
  private notifications: Map<number, Notification>;
  private dailyStats: Map<string, DailyStats>;
  private currentId: number;

  constructor() {
    this.users = new Map();
    this.monitoringConfigs = new Map();
    this.transactions = new Map();
    this.botConfigs = new Map();
    this.notifications = new Map();
    this.dailyStats = new Map();
    this.currentId = 1;

    // Initialize with default monitoring config
    this.initializeDefaultData();
  }

  private initializeDefaultData() {
    const defaultConfig: MonitoringConfig = {
      id: 1,
      walletAddress: "QPKJCvwZNMLnShg6nrEnVPt32u9j5Psdufy2cBoiSi1",
      tokenAddress: "",
      tokenSymbol: "GP",
      pollingInterval: 1,
      alertThreshold: 60,
      isActive: true,
      useAlternativeRpc: false,
      rpcEndpoint: "https://api.mainnet-beta.solana.com",
      createdAt: new Date(),
    };
    this.monitoringConfigs.set(1, defaultConfig);
    this.currentId = 2;
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.username === username);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async getMonitoringConfigs(): Promise<MonitoringConfig[]> {
    return Array.from(this.monitoringConfigs.values());
  }

  async getMonitoringConfig(id: number): Promise<MonitoringConfig | undefined> {
    return this.monitoringConfigs.get(id);
  }

  async createMonitoringConfig(config: InsertMonitoringConfig): Promise<MonitoringConfig> {
    const id = this.currentId++;
    const newConfig: MonitoringConfig = { 
      id,
      walletAddress: config.walletAddress,
      tokenAddress: config.tokenAddress,
      tokenSymbol: config.tokenSymbol || "GP",
      pollingInterval: config.pollingInterval || 1,
      alertThreshold: config.alertThreshold || 60,
      isActive: config.isActive ?? true,
      useAlternativeRpc: config.useAlternativeRpc ?? false,
      rpcEndpoint: config.rpcEndpoint || "https://api.mainnet-beta.solana.com",
      createdAt: new Date() 
    };
    this.monitoringConfigs.set(id, newConfig);
    return newConfig;
  }

  async updateMonitoringConfig(id: number, config: Partial<InsertMonitoringConfig>): Promise<MonitoringConfig | undefined> {
    const existing = this.monitoringConfigs.get(id);
    if (!existing) return undefined;
    
    const updated = { ...existing, ...config };
    this.monitoringConfigs.set(id, updated);
    return updated;
  }

  async deleteMonitoringConfig(id: number): Promise<boolean> {
    return this.monitoringConfigs.delete(id);
  }

  async getTransactions(limit = 50, offset = 0): Promise<Transaction[]> {
    const allTransactions = Array.from(this.transactions.values())
      .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
    return allTransactions.slice(offset, offset + limit);
  }

  async getTransactionsByConfig(configId: number, limit = 50): Promise<Transaction[]> {
    return Array.from(this.transactions.values())
      .filter(tx => tx.configId === configId)
      .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())
      .slice(0, limit);
  }

  async createTransaction(transaction: InsertTransaction): Promise<Transaction> {
    const id = this.currentId++;
    const newTransaction: Transaction = { 
      id,
      configId: transaction.configId || null,
      transactionHash: transaction.transactionHash,
      type: transaction.type,
      amount: transaction.amount,
      solValue: transaction.solValue || null,
      timestamp: transaction.timestamp,
      status: transaction.status || "confirmed",
      createdAt: new Date() 
    };
    this.transactions.set(id, newTransaction);
    return newTransaction;
  }

  async getTransactionByHash(hash: string): Promise<Transaction | undefined> {
    return Array.from(this.transactions.values()).find(tx => tx.transactionHash === hash);
  }

  async getBotConfigs(): Promise<BotConfig[]> {
    return Array.from(this.botConfigs.values());
  }

  async getBotConfig(type: string): Promise<BotConfig | undefined> {
    return this.botConfigs.get(type);
  }

  async upsertBotConfig(config: InsertBotConfig): Promise<BotConfig> {
    const existing = this.botConfigs.get(config.type);
    const id = existing?.id || this.currentId++;
    const botConfig: BotConfig = {
      id,
      type: config.type,
      isEnabled: config.isEnabled ?? true,
      config: config.config,
      notificationSettings: config.notificationSettings || "{}",
      updatedAt: new Date(),
    };
    this.botConfigs.set(config.type, botConfig);
    return botConfig;
  }

  async createNotification(notification: InsertNotification): Promise<Notification> {
    const id = this.currentId++;
    const newNotification: Notification = {
      id,
      type: notification.type,
      message: notification.message,
      platform: notification.platform,
      status: notification.status || "pending",
      transactionId: notification.transactionId || null,
      sentAt: null,
      createdAt: new Date(),
    };
    this.notifications.set(id, newNotification);
    return newNotification;
  }

  async getPendingNotifications(): Promise<Notification[]> {
    return Array.from(this.notifications.values())
      .filter(n => n.status === "pending");
  }

  async updateNotificationStatus(id: number, status: string, sentAt?: Date): Promise<void> {
    const notification = this.notifications.get(id);
    if (notification) {
      notification.status = status;
      if (sentAt) notification.sentAt = sentAt;
    }
  }

  async getDailyStats(date: string, configId?: number): Promise<DailyStats[]> {
    return Array.from(this.dailyStats.values())
      .filter(stats => stats.date === date && (!configId || stats.configId === configId));
  }

  async upsertDailyStats(stats: InsertDailyStats): Promise<DailyStats> {
    const key = `${stats.date}-${stats.configId}`;
    const existing = this.dailyStats.get(key);
    const id = existing?.id || this.currentId++;
    
    const dailyStat: DailyStats = { 
      id,
      date: stats.date,
      configId: stats.configId || null,
      totalBuybacks: stats.totalBuybacks || 0,
      totalAmount: stats.totalAmount || "0",
      totalSolVolume: stats.totalSolVolume || "0",
      tokensOut: stats.tokensOut || "0",
      avgFrequency: stats.avgFrequency || "0"
    };
    this.dailyStats.set(key, dailyStat);
    return dailyStat;
  }

  async getDashboardStats(configId?: number): Promise<DashboardStats> {
    const today = new Date().toISOString().split('T')[0];
    const weekAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString().split('T')[0];

    const todayStats = await this.getDailyStats(today, configId);
    const weekStats = Array.from(this.dailyStats.values())
      .filter(stats => stats.date >= weekAgo && (!configId || stats.configId === configId));

    const dailyBuybacks = todayStats.reduce((sum, s) => sum + Number(s.totalAmount), 0);
    const dailySol = todayStats.reduce((sum, s) => sum + Number(s.totalSolVolume), 0);
    const avgFreq = todayStats.length > 0 ? 
      todayStats.reduce((sum, s) => sum + Number(s.avgFrequency), 0) / todayStats.length : 0;
    const weeklyOutflow = weekStats.reduce((sum, s) => sum + Number(s.tokensOut), 0);

    const totalBuybacks = Array.from(this.transactions.values())
      .filter(tx => tx.type === 'buy_back' && (!configId || tx.configId === configId)).length;

    const totalVolume = Array.from(this.transactions.values())
      .filter(tx => tx.type === 'buy_back' && (!configId || tx.configId === configId))
      .reduce((sum, tx) => sum + Number(tx.solValue || 0), 0);

    return {
      dailyBuybacks: `${(dailyBuybacks / 1000000).toFixed(1)}M GP`,
      dailySol: `${dailySol.toFixed(1)} SOL`,
      avgFrequency: `${avgFreq.toFixed(1)} min`,
      weeklyOutflow: `${(weeklyOutflow / 1000).toFixed(0)}K GP`,
      totalBuybacks,
      totalVolume: `${totalVolume.toFixed(1)} SOL`,
    };
  }

  async getRecentTransactions(limit = 10): Promise<RealtimeTransaction[]> {
    const transactions = await this.getTransactions(limit);
    return transactions.map(tx => ({
      id: tx.id,
      type: tx.type === 'buy_back' ? 'Buy-back' : 'Token Out',
      amount: `${Number(tx.amount).toLocaleString()} GP`,
      solAmount: tx.solValue ? `${Number(tx.solValue).toFixed(1)} SOL` : undefined,
      timestamp: this.getRelativeTime(tx.timestamp),
      hash: this.formatHash(tx.transactionHash),
    }));
  }

  async getBotStatus(): Promise<BotStatus> {
    const telegramConfig = await this.getBotConfig('telegram');
    const notionConfig = await this.getBotConfig('notion');
    
    return {
      telegram: telegramConfig?.isEnabled || false,
      notion: notionConfig?.isEnabled || false,
      monitoring: true, // Always true for now
    };
  }

  private getRelativeTime(timestamp: Date): string {
    const now = new Date();
    const diff = now.getTime() - new Date(timestamp).getTime();
    const minutes = Math.floor(diff / 60000);
    
    if (minutes < 1) return 'Just now';
    if (minutes < 60) return `${minutes} minute${minutes > 1 ? 's' : ''} ago`;
    
    const hours = Math.floor(minutes / 60);
    if (hours < 24) return `${hours} hour${hours > 1 ? 's' : ''} ago`;
    
    const days = Math.floor(hours / 24);
    return `${days} day${days > 1 ? 's' : ''} ago`;
  }

  private formatHash(hash: string): string {
    if (hash.length <= 8) return hash;
    return `${hash.slice(0, 5)}...${hash.slice(-4)}`;
  }
}

export const storage = new MemStorage();
