import asyncio
import logging
import os
import json
from datetime import datetime, timedelta
from notion_client import Client
from notion_client.errors import APIResponseError as NotionClientError
import aiohttp

logger = logging.getLogger(__name__)

class NotionBot:
    def __init__(self):
        self.integration_secret = os.getenv('NOTION_INTEGRATION_SECRET', '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')
        self.page_url = os.getenv('NOTION_PAGE_URL', 'https://www.notion.so/22f49b677ce88019a815dc39212d6906')
        self.page_id = self.extract_page_id(self.page_url)
        self.database_id = None
        self.api_base = os.getenv('API_BASE_URL', 'http://localhost:5000/api')
        self.report_schedule = ["06:00", "12:00", "17:00", "24:00"]
        
        if self.integration_secret and self.integration_secret != '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':
            self.notion = Client(auth=self.integration_secret)
        else:
            self.notion = None
            logger.warning("Notion integration secret not configured")
    
    def extract_page_id(self, page_url: str) -> str:
        """Extract page ID from Notion URL."""
        import re
        match = re.search(r'([a-f0-9]{32})(?:[?#]|$)', page_url, re.IGNORECASE)
        if match:
            return match.group(1)
        raise ValueError("Failed to extract page ID from URL")
    
    async def setup_database(self):
        """Setup Notion database for monitoring reports."""
        if not self.notion:
            return False
            
        try:
            # Check if database already exists
            existing_db = await self.find_database_by_title("Token Monitoring Reports")
            if existing_db:
                self.database_id = existing_db['id']
                logger.info("Found existing Notion database")
                return True
            
            # Create new database
            database = self.notion.databases.create(
                parent={"type": "page_id", "page_id": self.page_id},
                title=[{"type": "text", "text": {"content": "Token Monitoring Reports"}}],
                properties={
                    "Report Date": {"title": {}},
                    "Total Buybacks": {"number": {}},
                    "Daily Volume (SOL)": {"number": {}},
                    "Avg Frequency (min)": {"number": {}},
                    "Tokens Out Today": {"number": {}},
                    "Tokens Out Week": {"number": {}},
                    "Tokens Out Total": {"number": {}},
                    "Report Type": {
                        "select": {
                            "options": [
                                {"name": "Daily", "color": "blue"},
                                {"name": "Alert", "color": "red"},
                                {"name": "Summary", "color": "green"}
                            ]
                        }
                    },
                    "Created At": {"date": {}}
                }
            )
            
            self.database_id = database['id']
            logger.info("Created new Notion database successfully")
            return True
            
        except NotionClientError as e:
            logger.error(f"Notion API error setting up database: {e}")
            return False
        except Exception as e:
            logger.error(f"Error setting up Notion database: {e}")
            return False
    
    async def find_database_by_title(self, title: str):
        """Find database by title in the page."""
        if not self.notion:
            return None
            
        try:
            # Get child blocks
            response = self.notion.blocks.children.list(block_id=self.page_id)
            
            for block in response.get('results', []):
                if block.get('type') == 'child_database':
                    # Get database details
                    db_info = self.notion.databases.retrieve(database_id=block['id'])
                    db_title = db_info.get('title', [])
                    
                    if db_title and len(db_title) > 0:
                        db_name = db_title[0].get('plain_text', '').lower()
                        if db_name == title.lower():
                            return db_info
            
            return None
            
        except Exception as e:
            logger.error(f"Error finding database: {e}")
            return None
    
    async def get_dashboard_stats(self):
        """Get dashboard statistics from API."""
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(f"{self.api_base}/dashboard/stats") as response:
                    if response.status == 200:
                        return await response.json()
                    else:
                        logger.error(f"Failed to get dashboard stats: {response.status}")
                        return None
        except Exception as e:
            logger.error(f"Error fetching dashboard stats: {e}")
            return None
    
    async def get_transaction_summary(self, days: int = 1):
        """Get transaction summary for the specified number of days."""
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(f"{self.api_base}/transactions?limit=1000") as response:
                    if response.status == 200:
                        transactions = await response.json()
                        
                        # Filter transactions by date
                        cutoff_date = datetime.now() - timedelta(days=days)
                        recent_transactions = []
                        
                        for tx in transactions:
                            tx_date = datetime.fromisoformat(tx['timestamp'].replace('Z', '+00:00'))
                            if tx_date >= cutoff_date:
                                recent_transactions.append(tx)
                        
                        # Calculate summary
                        buy_backs = [tx for tx in recent_transactions if tx['type'] == 'buy_back']
                        token_outs = [tx for tx in recent_transactions if tx['type'] == 'token_out']
                        
                        total_buybacks = len(buy_backs)
                        total_amount = sum(float(tx.get('amount', 0)) for tx in buy_backs)
                        total_sol = sum(float(tx.get('solValue', 0)) for tx in buy_backs if tx.get('solValue'))
                        tokens_out = sum(float(tx.get('amount', 0)) for tx in token_outs)
                        
                        # Calculate average frequency
                        avg_frequency = 0
                        if len(buy_backs) > 1:
                            time_diffs = []
                            for i in range(1, len(buy_backs)):
                                prev_time = datetime.fromisoformat(buy_backs[i-1]['timestamp'].replace('Z', '+00:00'))
                                curr_time = datetime.fromisoformat(buy_backs[i]['timestamp'].replace('Z', '+00:00'))
                                diff_minutes = (prev_time - curr_time).total_seconds() / 60
                                time_diffs.append(abs(diff_minutes))
                            
                            if time_diffs:
                                avg_frequency = sum(time_diffs) / len(time_diffs)
                        
                        return {
                            'total_buybacks': total_buybacks,
                            'total_amount': total_amount,
                            'total_sol': total_sol,
                            'tokens_out': tokens_out,
                            'avg_frequency': avg_frequency
                        }
                    else:
                        logger.error(f"Failed to get transactions: {response.status}")
                        return None
        except Exception as e:
            logger.error(f"Error fetching transaction summary: {e}")
            return None
    
    async def create_report(self, report_type: str = "scheduled"):
        """Create a report in Notion."""
        if not self.notion or not self.database_id:
            logger.warning("Notion not configured or database not set up")
            return False
        
        try:
            now = datetime.now()
            today = now.strftime('%Y-%m-%d')
            
            # Get data for report
            stats = await self.get_dashboard_stats()
            daily_summary = await self.get_transaction_summary(days=1)
            weekly_summary = await self.get_transaction_summary(days=7)
            
            if not stats or not daily_summary:
                logger.error("Failed to get data for report")
                return False
            
            report_title = f"Token Monitoring Report - {today}"
            if report_type == "alert":
                report_title = f"Alert Report - {now.strftime('%Y-%m-%d %H:%M')}"
            
            # Create report content
            report_content = f"""📊 **Token Monitoring Report**
📅 **Tanggal:** {now.strftime('%d/%m/%Y %H:%M')}

📈 **Ringkasan Hari Ini:**
• Total transaksi buy-back: {daily_summary['total_buybacks']}
• Total volume SOL: {daily_summary['total_sol']:.2f} SOL
• Rata-rata frekuensi: {daily_summary['avg_frequency']:.1f} menit
• Token keluar hari ini: {daily_summary['tokens_out']:,.0f} GP

📊 **Ringkasan Minggu Ini:**
• Total token keluar: {weekly_summary['tokens_out']:,.0f} GP
• Total buy-back: {weekly_summary['total_buybacks']} transaksi

⚡ **Status Sistem:**
• Monitoring: Aktif
• Last Update: {now.strftime('%H:%M:%S')}"""
            
            # Create page in database
            new_page = self.notion.pages.create(
                parent={"database_id": self.database_id},
                properties={
                    "Report Date": {
                        "title": [{"type": "text", "text": {"content": report_title}}]
                    },
                    "Total Buybacks": {"number": daily_summary['total_buybacks']},
                    "Daily Volume (SOL)": {"number": round(daily_summary['total_sol'], 2)},
                    "Avg Frequency (min)": {"number": round(daily_summary['avg_frequency'], 1)},
                    "Tokens Out Today": {"number": int(daily_summary['tokens_out'])},
                    "Tokens Out Week": {"number": int(weekly_summary['tokens_out'])},
                    "Tokens Out Total": {"number": int(weekly_summary['tokens_out'])},  # For now, same as weekly
                    "Report Type": {
                        "select": {"name": "Alert" if report_type == "alert" else "Daily"}
                    },
                    "Created At": {"date": {"start": now.isoformat()}}
                },
                children=[
                    {
                        "object": "block",
                        "type": "paragraph",
                        "paragraph": {
                            "rich_text": [
                                {"type": "text", "text": {"content": report_content}}
                            ]
                        }
                    }
                ]
            )
            
            logger.info(f"Created Notion report: {report_title}")
            return True
            
        except NotionClientError as e:
            logger.error(f"Notion API error creating report: {e}")
            return False
        except Exception as e:
            logger.error(f"Error creating Notion report: {e}")
            return False
    
    async def process_pending_notifications(self):
        """Process pending Notion notifications."""
        try:
            # In a real implementation, this would fetch pending notifications
            # from the API and create reports for significant events
            pass
        except Exception as e:
            logger.error(f"Error processing notifications: {e}")
    
    async def scheduled_report_check(self):
        """Check if it's time for a scheduled report."""
        now = datetime.now()
        current_time = now.strftime('%H:%M')
        
        if current_time in self.report_schedule:
            logger.info(f"Creating scheduled report at {current_time}")
            await self.create_report("scheduled")
    
    async def start(self):
        """Start the Notion bot service."""
        logger.info("Starting Notion bot service...")
        
        # Setup database
        if self.notion:
            setup_success = await self.setup_database()
            if not setup_success:
                logger.error("Failed to setup Notion database")
                return
        else:
            logger.warning("Notion bot running without valid configuration")
        
        # Main loop
        while True:
            try:
                # Process notifications every 30 seconds
                await self.process_pending_notifications()
                
                # Check for scheduled reports every minute
                if datetime.now().second == 0:  # At the start of each minute
                    await self.scheduled_report_check()
                
                await asyncio.sleep(30)
                
            except Exception as e:
                logger.error(f"Error in Notion bot loop: {e}")
                await asyncio.sleep(5)
