import asyncio
import logging
import os
import json
from datetime import datetime, timedelta
from solana.rpc.async_api import AsyncClient
from solana.publickey import PublicKey
from solana.rpc.commitment import Commitment
import aiohttp

logger = logging.getLogger(__name__)

class SolanaMonitor:
    def __init__(self):
        self.rpc_url = os.getenv('SOLANA_RPC_URL', 'https://api.mainnet-beta.solana.com')
        self.client = AsyncClient(self.rpc_url)
        self.wallet_address = os.getenv('WALLET_ADDRESS', 'QPKJCvwZNMLnShg6nrEnVPt32u9j5Psdufy2cBoiSi1')
        self.token_address = os.getenv('TOKEN_ADDRESS', '')
        self.polling_interval = int(os.getenv('POLLING_INTERVAL', '60'))  # seconds
        self.api_base = os.getenv('API_BASE_URL', 'http://localhost:5000/api')
        self.processed_signatures = set()
        self.last_signature = None
        
        # Initialize webhook clients
        self.telegram_bot = None
        self.notion_bot = None
        
    async def get_wallet_transactions(self, limit: int = 10):
        """Get recent transactions for the monitored wallet."""
        try:
            wallet_pubkey = PublicKey(self.wallet_address)
            
            # Get signatures for address
            response = await self.client.get_signatures_for_address(
                wallet_pubkey,
                limit=limit,
                commitment=Commitment("confirmed")
            )
            
            if response.value:
                return response.value
            else:
                logger.warning("No transactions found for wallet")
                return []
                
        except Exception as e:
            logger.error(f"Error fetching wallet transactions: {e}")
            return []
    
    async def get_transaction_details(self, signature: str):
        """Get detailed transaction information."""
        try:
            response = await self.client.get_transaction(
                signature,
                commitment=Commitment("confirmed"),
                max_supported_transaction_version=0
            )
            
            if response.value:
                return response.value
            else:
                logger.warning(f"Transaction details not found for {signature}")
                return None
                
        except Exception as e:
            logger.error(f"Error fetching transaction details for {signature}: {e}")
            return None
    
    def analyze_transaction(self, transaction_data, signature: str):
        """Analyze transaction to determine if it's a buy-back or token outflow."""
        try:
            if not transaction_data or not transaction_data.transaction:
                return None
            
            meta = transaction_data.meta
            if not meta:
                return None
            
            # Check for SOL balance changes
            pre_balances = meta.pre_balances or []
            post_balances = meta.post_balances or []
            
            if len(pre_balances) == 0 or len(post_balances) == 0:
                return None
            
            # Calculate SOL balance change for the main account
            sol_change = (post_balances[0] - pre_balances[0]) / 1e9  # Convert lamports to SOL
            
            # Determine transaction type based on SOL flow
            if sol_change < -0.001:  # SOL decreased (spent) - likely buy-back
                estimated_gp_amount = abs(sol_change) * 1000000  # Rough estimation
                return {
                    'type': 'buy_back',
                    'amount': estimated_gp_amount,
                    'sol_value': abs(sol_change),
                    'signature': signature,
                    'timestamp': datetime.now()
                }
            elif sol_change > 0.001:  # SOL increased (received) - might be token sale
                estimated_gp_amount = sol_change * 500000  # Different estimation for outflow
                return {
                    'type': 'token_out',
                    'amount': estimated_gp_amount,
                    'sol_value': None,
                    'signature': signature,
                    'timestamp': datetime.now()
                }
            
            return None
            
        except Exception as e:
            logger.error(f"Error analyzing transaction {signature}: {e}")
            return None
    
    async def save_transaction(self, transaction_analysis):
        """Save transaction to the API."""
        try:
            transaction_data = {
                'configId': 1,  # Default config ID
                'transactionHash': transaction_analysis['signature'],
                'type': transaction_analysis['type'],
                'amount': str(transaction_analysis['amount']),
                'solValue': str(transaction_analysis['sol_value']) if transaction_analysis['sol_value'] else None,
                'timestamp': transaction_analysis['timestamp'].isoformat(),
                'status': 'confirmed'
            }
            
            async with aiohttp.ClientSession() as session:
                async with session.post(
                    f"{self.api_base}/transactions",
                    json=transaction_data,
                    headers={'Content-Type': 'application/json'}
                ) as response:
                    if response.status == 201:
                        logger.info(f"Transaction saved: {transaction_analysis['signature'][:8]}...")
                        return True
                    else:
                        logger.error(f"Failed to save transaction: {response.status}")
                        return False
                        
        except Exception as e:
            logger.error(f"Error saving transaction: {e}")
            return False
    
    async def send_telegram_notification(self, transaction_analysis):
        """Send notification to Telegram bot."""
        try:
            if transaction_analysis['type'] == 'buy_back':
                message = f"🔥 Buy-back Terdeteksi! 💰\nJumlah: {transaction_analysis['amount']:,.0f} GP\nSOL: {transaction_analysis['sol_value']:.3f}"
            else:
                message = f"🚨 Pergerakan Token!\nToken GP keluar: {transaction_analysis['amount']:,.0f} GP"
            
            # In a real implementation, this would call the Telegram bot
            logger.info(f"Telegram notification: {message}")
            
        except Exception as e:
            logger.error(f"Error sending Telegram notification: {e}")
    
    async def send_notion_alert(self, transaction_analysis):
        """Send alert to Notion for significant events."""
        try:
            if (transaction_analysis['type'] == 'token_out' or 
                transaction_analysis['amount'] > 100000):
                
                # In a real implementation, this would trigger Notion report creation
                logger.info(f"Notion alert triggered for {transaction_analysis['type']}")
                
        except Exception as e:
            logger.error(f"Error sending Notion alert: {e}")
    
    async def check_new_transactions(self):
        """Check for new transactions and process them."""
        try:
            signatures = await self.get_wallet_transactions(limit=20)
            
            if not signatures:
                return
            
            new_transactions_found = False
            
            for sig_info in signatures:
                signature = sig_info.signature
                
                # Skip if we've already processed this transaction
                if signature in self.processed_signatures:
                    continue
                
                # Stop at the last signature we processed
                if self.last_signature and signature == self.last_signature:
                    break
                
                # Get transaction details
                transaction_data = await self.get_transaction_details(signature)
                
                if transaction_data:
                    # Analyze the transaction
                    analysis = self.analyze_transaction(transaction_data, signature)
                    
                    if analysis:
                        logger.info(f"New {analysis['type']} detected: {signature[:8]}...")
                        
                        # Save to database
                        await self.save_transaction(analysis)
                        
                        # Send notifications
                        await self.send_telegram_notification(analysis)
                        await self.send_notion_alert(analysis)
                        
                        new_transactions_found = True
                
                # Mark as processed
                self.processed_signatures.add(signature)
            
            # Update last signature
            if signatures and new_transactions_found:
                self.last_signature = signatures[0].signature
                
        except Exception as e:
            logger.error(f"Error checking new transactions: {e}")
    
    async def cleanup_processed_signatures(self):
        """Clean up old processed signatures to prevent memory bloat."""
        if len(self.processed_signatures) > 1000:
            # Keep only the latest 500 signatures
            latest_signatures = list(self.processed_signatures)[-500:]
            self.processed_signatures = set(latest_signatures)
            logger.info("Cleaned up processed signatures cache")
    
    async def start(self):
        """Start the Solana monitoring service."""
        logger.info(f"Starting Solana monitor for wallet: {self.wallet_address}")
        logger.info(f"Polling interval: {self.polling_interval} seconds")
        
        # Test connection
        try:
            version = await self.client.get_version()
            logger.info(f"Connected to Solana RPC: {version.value}")
        except Exception as e:
            logger.error(f"Failed to connect to Solana RPC: {e}")
            return
        
        # Initialize with recent transactions
        try:
            initial_signatures = await self.get_wallet_transactions(limit=5)
            if initial_signatures:
                self.last_signature = initial_signatures[0].signature
                for sig_info in initial_signatures:
                    self.processed_signatures.add(sig_info.signature)
                logger.info(f"Initialized with {len(initial_signatures)} recent transactions")
        except Exception as e:
            logger.error(f"Error during initialization: {e}")
        
        # Main monitoring loop
        while True:
            try:
                await self.check_new_transactions()
                
                # Cleanup every hour
                if datetime.now().minute == 0 and datetime.now().second < self.polling_interval:
                    await self.cleanup_processed_signatures()
                
                await asyncio.sleep(self.polling_interval)
                
            except Exception as e:
                logger.error(f"Error in monitoring loop: {e}")
                await asyncio.sleep(5)  # Short sleep before retrying
            
        # Close client on exit
        await self.client.close()
