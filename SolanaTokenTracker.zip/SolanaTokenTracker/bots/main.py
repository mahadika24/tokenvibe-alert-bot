import asyncio
import logging
import os
from dotenv import load_dotenv
from telegram_bot import TelegramBot
from notion_bot import NotionBot
from solana_monitor import SolanaMonitor

# Load environment variables
load_dotenv()

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

async def main():
    """Main function to start all bots and monitoring services."""
    logger.info("Starting Solana Token Monitoring System...")
    
    try:
        # Initialize services
        telegram_bot = TelegramBot()
        notion_bot = NotionBot()
        solana_monitor = SolanaMonitor()
        
        # Start all services concurrently
        tasks = [
            telegram_bot.start(),
            notion_bot.start(),
            solana_monitor.start(),
        ]
        
        logger.info("All services started successfully")
        
        # Run all tasks concurrently
        await asyncio.gather(*tasks)
        
    except KeyboardInterrupt:
        logger.info("Received shutdown signal, stopping services...")
    except Exception as e:
        logger.error(f"Error in main loop: {e}")
    finally:
        logger.info("Shutting down...")

if __name__ == "__main__":
    asyncio.run(main())
