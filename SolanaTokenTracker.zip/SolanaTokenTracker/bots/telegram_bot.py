import asyncio
import logging
import os
import json
from datetime import datetime, timedelta
from telegram import Bot
from telegram.error import TelegramError
import aiohttp

logger = logging.getLogger(__name__)

class TelegramBot:
    def __init__(self):
        self.bot_token = os.getenv('TELEGRAM_BOT_TOKEN', '8178383755:AAH5OwUM7GJq-OSx1dpieYB7lli-xuPjKhw')
        self.chat_id = os.getenv('TELEGRAM_CHAT_ID', '')
        self.bot = Bot(token=self.bot_token)
        self.last_activity_alert = None
        self.api_base = os.getenv('API_BASE_URL', 'http://localhost:5000/api')
        
    async def send_message(self, message: str) -> bool:
        """Send message to Telegram chat."""
        if not self.chat_id:
            logger.warning("Telegram chat ID not configured")
            return False
            
        try:
            await self.bot.send_message(
                chat_id=self.chat_id,
                text=message,
                parse_mode='HTML'
            )
            logger.info("Telegram message sent successfully")
            return True
        except TelegramError as e:
            logger.error(f"Failed to send Telegram message: {e}")
            return False
        except Exception as e:
            logger.error(f"Unexpected error sending Telegram message: {e}")
            return False
    
    async def send_buyback_notification(self, amount: str, sol_value: str = None):
        """Send buy-back notification."""
        message = f"""🔥 <b>Buy-back Terdeteksi!</b> 💰

<b>Jumlah:</b> {amount} GP
{f'<b>SOL Value:</b> {sol_value}' if sol_value else ''}
⏰ <b>Waktu:</b> {datetime.now().strftime('%H:%M:%S')}

🔁 Monitoring tetap berjalan..."""
        
        await self.send_message(message)
    
    async def send_token_outflow_alert(self, amount: str):
        """Send token outflow alert."""
        message = f"""🚨 <b>Pergerakan Token!</b>

🔁 Token GP keluar dari wallet buy-back:
<b>Jumlah:</b> {amount} GP
⏰ <b>Waktu:</b> {datetime.now().strftime('%H:%M:%S')}

🚨 <b>Peringatan:</b> Segera cek aktivitas wallet!"""
        
        await self.send_message(message)
    
    async def send_inactivity_alert(self, minutes: int):
        """Send inactivity alert."""
        message = f"""⚠️ <b>Peringatan!</b>

❌ Tidak ada buy-back selama <b>{minutes} menit</b> terakhir.
🚨 Mohon segera cek aktivitas wallet tim!

⏰ <b>Last Activity:</b> {minutes} menit yang lalu"""
        
        await self.send_message(message)
    
    async def get_pending_notifications(self):
        """Get pending notifications from API."""
        try:
            async with aiohttp.ClientSession() as session:
                # This would be replaced with actual API call to get pending notifications
                # For now, we'll implement a simple check
                pass
        except Exception as e:
            logger.error(f"Error fetching pending notifications: {e}")
            return []
    
    async def check_inactivity(self):
        """Check for inactivity and send alerts."""
        try:
            async with aiohttp.ClientSession() as session:
                # Get recent transactions to check for inactivity
                async with session.get(f"{self.api_base}/transactions?limit=1") as response:
                    if response.status == 200:
                        transactions = await response.json()
                        
                        if transactions and len(transactions) > 0:
                            last_tx = transactions[0]
                            last_timestamp = datetime.fromisoformat(last_tx['timestamp'].replace('Z', '+00:00'))
                            now = datetime.now(last_timestamp.tzinfo)
                            time_diff = now - last_timestamp
                            minutes_diff = time_diff.total_seconds() / 60
                            
                            # Alert if no activity for more than 60 minutes
                            if minutes_diff > 60:
                                current_time = datetime.now()
                                # Avoid spam alerts - only send once per hour
                                if (not self.last_activity_alert or 
                                    current_time - self.last_activity_alert > timedelta(hours=1)):
                                    await self.send_inactivity_alert(int(minutes_diff))
                                    self.last_activity_alert = current_time
        except Exception as e:
            logger.error(f"Error checking inactivity: {e}")
    
    async def process_notifications(self):
        """Process pending notifications."""
        try:
            # In a real implementation, this would fetch from the API
            # and process Telegram notifications
            pass
        except Exception as e:
            logger.error(f"Error processing notifications: {e}")
    
    async def start(self):
        """Start the Telegram bot service."""
        logger.info("Starting Telegram bot service...")
        
        # Test bot connection
        try:
            bot_info = await self.bot.get_me()
            logger.info(f"Telegram bot connected: @{bot_info.username}")
        except Exception as e:
            logger.error(f"Failed to connect to Telegram bot: {e}")
            return
        
        # Main loop
        while True:
            try:
                # Process notifications every 10 seconds
                await self.process_notifications()
                
                # Check for inactivity every 5 minutes
                if datetime.now().second % 300 == 0:  # Every 5 minutes
                    await self.check_inactivity()
                
                await asyncio.sleep(10)
                
            except Exception as e:
                logger.error(f"Error in Telegram bot loop: {e}")
                await asyncio.sleep(5)
